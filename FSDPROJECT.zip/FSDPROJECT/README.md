# SmartPark

SmartPark is a parking management application with a plain HTML, CSS, and browser JavaScript interface and a Python server backed by SQLite. The backend uses Python's standard library; there are no packages to install.

## Run on Windows

Install Python 3.10 or later, open PowerShell in this folder, and start the server:

```powershell
python server.py
```

If the Python launcher is installed instead, use:

```powershell
py server.py
```

Open <http://127.0.0.1:3000>. Leaflet map tiles and fonts load from external services, so an internet connection is needed for those parts of the interface. Parking slot counts remain visible in the map's facility list if map tiles cannot load.

The first visit asks you to create an administrator account. There is no default username or password. Administrators can add team accounts and issue single-use, 30-minute invitation or password-reset codes; share those codes privately with the intended user.

## Database and backups

The server creates and updates `data/smartpark.sqlite` automatically. A new installation starts with no facilities, users, or sample bookings. Create the first administrator account, then add real facilities and inventory in Business Config. Parking facilities, vehicle-specific inventory and rates, bookings, occupancy sessions, simulated payments, messages, support cases, users, settings, and audit records are stored in SQLite; dashboard totals and availability are calculated from those saved records.

Set `SMARTPARK_DB_PATH` to use another database file, `PORT` to choose a different port, or `HOST` to change the bind address:

```powershell
$env:SMARTPARK_DB_PATH = "C:\path\to\smartpark.sqlite"
$env:PORT = "3100"
python server.py
```

The administrator-only `POST /api/backup` endpoint downloads a consistent SQLite backup. Payments are simulated; no card or payment gateway is connected. Authentication uses HTTP-only session cookies and password hashes. Customers can view their own bookings and support requests; parking operators are restricted to their assigned facility.

## Application modules

Home, map display, parking operations, facility configuration, reservations, parking data, message center, customer service, statistics, finance, and system management are available from the sidebar. The map uses live records from the application database; its distance values are straight-line estimates, not turn-by-turn route distances. Facility locations include Google Maps directions links based on their saved coordinates, and the map's facility list shows total, occupied, reserved, and available spaces for the selected vehicle type. Select a facility marker or choose "View individual slots" to inspect its numbered bays; occupied bays reflect active check-ins, while reservations remain unassigned until check-in. Choose "Show my location" on the map to request browser location permission and display your approximate current position; your location is not saved. If no permission prompt appears, open the site's location permission from the browser address-bar controls and allow access; device location services must also be on.

## API overview

The JSON API is served by the same Python application:

- `GET /api/auth/session`, `POST /api/auth/setup`, `POST /api/auth/login`
- `GET /api/home`, `GET /api/stats?period=day|week|month`
- `GET /api/facilities`, `POST /api/facilities`, `PATCH /api/facilities/:id`
- `GET /api/bookings`, `POST /api/bookings`, `POST /api/bookings/:id/cancel`
- `POST /api/operations/entry`, `POST /api/operations/exit`
- `GET /api/parking-data`, `GET /api/notifications`, `GET /api/support`
- `POST /api/export` with `{"type":"facilities"}` or `{"type":"transactions"}`

All workspace APIs require a signed-in account and enforce role and facility permissions on the server.
