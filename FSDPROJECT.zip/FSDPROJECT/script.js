"use strict";

const VEHICLE_TYPES = ["bike", "car", "auto", "bicycle", "bus", "truck"];
const VEHICLE_NAMES = { bike: "Bike", car: "Car", auto: "Auto rickshaw", bicycle: "Bicycle", bus: "Bus", truck: "Truck" };
const CURRENCY = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 });
const COUNT = new Intl.NumberFormat("en-IN");
const MODULE_NAMES = {
    home: "Home", map: "Map Display", operations: "Operations", "business-config": "Business Config",
    "business-processing": "Business Processing", "parking-data": "Parking Data", "message-center": "Message Center",
    "customer-service": "Customer Service", statistics: "Statistics", finance: "Finance", "system-management": "System Management"
};

const content = document.getElementById("module-content");
const formDialog = document.getElementById("form-modal");
const form = document.getElementById("modal-form");
const formFields = document.getElementById("form-fields");
const notificationCount = document.getElementById("notification-count");
const notificationPip = document.getElementById("notification-pip");
let currentModule = "home";
let currentMap;
let currentMarkers;
let currentLocationLayer;
let selectedFacilityId = null;
let currentUser = null;
let toastTimeout;
let modalSubmit;
let authMode = "login";

function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (character) => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;"
    })[character]);
}

function notify(message, error = false) {
    const toast = document.getElementById("toast");
    toast.textContent = message;
    toast.classList.toggle("error", error);
    toast.hidden = false;
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => { toast.hidden = true; }, 4000);
}

async function api(route, options = {}) {
    const headers = { ...options.headers };
    if (options.body !== undefined && !(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
    const response = await fetch(route, {
        ...options,
        headers,
        body: options.body !== undefined && !(options.body instanceof FormData) ? JSON.stringify(options.body) : options.body
    });
    if (!response.ok) {
        let message = `Request failed (${response.status}).`;
        try { message = (await response.json()).error || message; }
        catch { /* A failed text download has no JSON response body. */ }
        throw new Error(message);
    }
    return response.status === 204 ? null : response.json();
}

function panel(title, detail, body, tools = "") {
    return `<section class="panel"><div class="panel-heading"><div><h2>${title}</h2>${detail ? `<p>${detail}</p>` : ""}</div>${tools}</div>${body}</section>`;
}

function actionButton(label, action, id, style = "button-outline", extra = "") {
    return `<button class="button ${style}" type="button" data-action="${escapeHtml(action)}" data-id="${escapeHtml(id)}" ${extra}>${label}</button>`;
}

function emptyState(title, detail, symbol = "◎") {
    return `<div class="empty-state"><span class="empty-symbol">${symbol}</span><strong>${escapeHtml(title)}</strong><p>${escapeHtml(detail)}</p></div>`;
}

function formatDate(value, withTime = true) {
    if (!value) return "—";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return escapeHtml(value);
    return new Intl.DateTimeFormat(undefined, withTime ? { dateStyle: "medium", timeStyle: "short" } : { dateStyle: "medium" }).format(date);
}

function mapsDirectionsLink(facility, className = "maps-link") {
    const destination = encodeURIComponent(`${facility.latitude},${facility.longitude}`);
    const href = `https://www.google.com/maps/dir/?api=1&destination=${destination}`;
    return `<a class="${className}" href="${href}" target="_blank" rel="noopener noreferrer">Open in Google Maps ↗</a>`;
}

function statusBadge(value) {
    const slug = String(value || "unknown").toLowerCase().replace(/[^a-z0-9]+/g, "-");
    return `<span class="status-badge status-${escapeHtml(slug)}">${escapeHtml(String(value || "Unknown").replace(/_/g, " "))}</span>`;
}

function pageIntro(title, description, actionLabel = "", action = "") {
    return `<div class="page-intro"><div><span class="eyebrow">${escapeHtml(title.toUpperCase())}</span><p>${escapeHtml(description)}</p></div>${actionLabel ? `<button class="button button-primary" type="button" data-action="${escapeHtml(action)}">＋ ${escapeHtml(actionLabel)}</button>` : ""}</div>`;
}

function facilityTable(facilities, withActions = false) {
    if (!facilities.length) return emptyState("No parking facilities yet", "Add a facility to begin managing parking operations.");
    return `<div class="table-wrap"><table><thead><tr><th>Facility</th><th>Location</th><th>Capacity</th><th>Occupied</th><th>Reserved</th><th>Available</th><th>Vehicle types</th>${withActions ? "<th>Actions</th>" : ""}</tr></thead><tbody>${
        facilities.map((facility) => `<tr><td><span class="table-primary">${escapeHtml(facility.name)}</span><span class="table-sub">${escapeHtml(facility.zone)}</span></td><td>${escapeHtml(facility.area)}<span class="table-sub">${escapeHtml(facility.address)}</span>${mapsDirectionsLink(facility, "maps-link maps-link-table")}</td><td>${COUNT.format(facility.capacity)}</td><td>${COUNT.format(facility.occupiedSpaces)}</td><td>${COUNT.format(facility.reservedSpaces)}</td><td><strong>${COUNT.format(facility.availableSpaces)}</strong></td><td>${facility.supportedVehicles.map((type) => `<span class="type-chip">${escapeHtml(VEHICLE_NAMES[type] || type)}</span>`).join(" ")}</td>${withActions ? `<td class="table-actions">${actionButton("Edit", "edit-facility", facility.id)}${actionButton(facility.active ? "Deactivate" : "Activate", "toggle-facility", facility.id, "button-quiet")}</td>` : ""}</tr>`).join("")
    }</tbody></table></div>`;
}

function renderHome(dashboard) {
    const metrics = [
        ["Registered facilities", COUNT.format(dashboard.totalFacilities), "⌂", "Across all active areas"],
        ["Total parking spaces", COUNT.format(dashboard.totalSpaces), "▣", "Physical facility capacity"],
        ["Spaces occupied", COUNT.format(dashboard.occupiedSpaces), "↗", "Vehicles currently parked"],
        ["Spaces available", COUNT.format(dashboard.availableSpaces), "◎", "After physical occupancy and reservations"],
        ["Active bookings", COUNT.format(dashboard.activeBookings), "▤", "Confirmed and checked-in reservations"],
        ["Cancelled bookings", COUNT.format(dashboard.cancelledBookings), "↩", "Cancelled reservations"]
    ];
    const metricCards = metrics.map(([label, value, icon, helper], index) => `<article class="metric-card"><span class="metric-icon metric-icon-${index}">${icon}</span><span class="metric-label">${label}</span><strong>${value}</strong><span class="metric-helper">${helper}</span></article>`).join("");
    const alerts = dashboard.alerts.length
        ? dashboard.alerts.map((alert) => `<div class="alert-row alert-${escapeHtml(alert.type)}"><span class="alert-icon">${alert.type === "full" ? "!" : "◷"}</span><div><strong>${escapeHtml(alert.facility)}</strong><span>${escapeHtml(alert.message)}</span></div><button type="button" class="text-button" data-action="open-facility" data-id="${escapeHtml(alert.facilityId)}">View</button></div>`).join("")
        : `<div class="quiet-message"><span class="online-dot"></span>No full or outdated facilities right now.</div>`;
    const recent = dashboard.recentFacilities.map((facility) => `<button type="button" class="recent-row" data-action="open-facility" data-id="${escapeHtml(facility.id)}"><span class="recent-pin">◎</span><span><strong>${escapeHtml(facility.name)}</strong><span>${escapeHtml(facility.area)} · ${escapeHtml(facility.source)}</span></span><span class="recent-time">${formatDate(facility.updatedAt)}</span></button>`).join("");
    const bookings = dashboard.recentBookings.length
        ? `<div class="table-wrap"><table><thead><tr><th>Confirmation</th><th>Customer</th><th>Facility</th><th>Vehicle</th><th>Status</th><th>Arrival</th></tr></thead><tbody>${dashboard.recentBookings.map((booking) => `<tr><td><strong>${escapeHtml(booking.id)}</strong></td><td>${escapeHtml(booking.customer_name)}</td><td>${escapeHtml(booking.facility_name)}</td><td>${escapeHtml(VEHICLE_NAMES[booking.vehicle_type] || booking.vehicle_type)}</td><td>${statusBadge(booking.status)}</td><td>${formatDate(booking.starts_at)}</td></tr>`).join("")}</tbody></table></div>`
        : emptyState("No bookings yet", "Reservations and booking updates will appear here.", "▤");
    const customer = currentUser?.role === "customer";
    const quickActions = customer
        ? `<button type="button" data-module-link="map"><span>◎</span>Find parking</button><button type="button" data-action="new-booking"><span>▤</span>Create reservation</button><button type="button" data-module-link="business-processing"><span>▤</span>View my bookings</button><button type="button" data-action="new-support"><span>♧</span>Report a problem</button>`
        : `<button type="button" data-module-link="map"><span>◎</span>Find parking</button><button type="button" data-action="entry"><span>↗</span>Record vehicle entry</button><button type="button" data-action="new-booking"><span>▤</span>Create reservation</button><button type="button" data-action="new-facility"><span>＋</span>Add facility</button><button type="button" data-action="new-message"><span>✉</span>Send a message</button><button type="button" data-module-link="parking-data"><span>▦</span>Export parking data</button>`;
    content.innerHTML = `${pageIntro("Network overview", "An up-to-date view of facility availability, reservations, and operational alerts.")}<div class="metric-grid">${metricCards}</div><div class="dashboard-grid"><div>${panel("Availability alerts", "Full parking areas and availability that needs attention.", `<div class="alert-list">${alerts}</div>`)}${panel("Recently updated facilities", "The latest reported availability updates.", recent ? `<div class="recent-list">${recent}</div>` : emptyState("No facilities found", "Register parking facilities to start tracking updates."))}</div><aside class="quick-column">${panel("Quick access", "Go directly to a common task.", `<div class="quick-grid">${quickActions}</div>`)}${panel("Network occupancy", `${COUNT.format(dashboard.occupiedSpaces)} occupied · ${COUNT.format(dashboard.availableSpaces)} available · ${COUNT.format(dashboard.reservedSpaces)} reserved`, `<div class="progress-track"><span class="progress-fill" style="width:${Math.max(0, Math.min(100, dashboard.occupancyRate))}%"></span></div><div class="progress-labels"><span>${dashboard.occupancyRate}% committed capacity</span><span>Physical parking and active reservations</span></div>`)}</aside></div>${panel("Recent bookings", "A live view of the latest customer reservations.", bookings, customer ? "" : `<button class="button button-outline" type="button" data-module-link="business-processing">View bookings</button>`)}`;
}

function createMarkerIcon(facility, vehicleType) {
    const inventory = facility.vehicles.find((vehicle) => vehicle.vehicleType === vehicleType);
    const available = inventory?.availableSpaces || 0;
    const state = facility.temporarilyClosed ? "closed" : available === 0 ? "full" : available / Math.max(inventory.capacity, 1) <= 0.15 ? "limited" : "available";
    return L.divIcon({
        className: "",
        html: `<div class="map-marker marker-${state}" title="${escapeHtml(facility.name)}"><span>${available}</span></div>`,
        iconSize: [38, 42],
        iconAnchor: [19, 38],
        popupAnchor: [0, -34]
    });
}

async function renderMap() {
    const [facilities, home] = await Promise.all([api("/api/facilities"), api("/api/home")]);
    const filterControls = `<div class="map-filters"><label class="map-search"><span>⌕</span><input id="facility-search" type="search" placeholder="Search city, area, landmark or destination" aria-label="Search parking locations" value=""></label><label class="select-field"><span>VEHICLE</span><select id="map-vehicle">${VEHICLE_TYPES.map((type) => `<option value="${type}" ${type === "car" ? "selected" : ""}>${escapeHtml(VEHICLE_NAMES[type])}</option>`).join("")}</select></label><label class="select-field"><span>AREA</span><select id="map-zone"><option value="">All areas</option>${home.zones.map((zone) => `<option value="${escapeHtml(zone)}">${escapeHtml(zone)}</option>`).join("")}</select></label><button class="button button-outline map-location-button" id="show-my-location" type="button">◎ Show my location</button></div><p class="map-status map-location-status" id="map-location-status" role="status" aria-live="polite" hidden></p>`;
    content.innerHTML = `${pageIntro("Parking map", "Find nearby facilities, compare live vehicle-specific availability and pricing.")}${panel("Find your next parking spot", "", `<div class="map-module">${filterControls}<div class="map-layout"><div><div id="module-map" role="application" aria-label="Interactive SmartPark facility map"></div><p class="map-status" id="map-tile-status" role="status" hidden></p></div><aside class="map-detail" id="map-detail">${emptyState("Select a parking marker", "Facility prices, hours, availability and nearby alternatives will appear here.", "◎")}</aside></div><section class="map-slots" aria-live="polite"><h3 id="map-slots-heading">Parking slot availability</h3><div id="map-slot-list"></div></section><section class="parking-layout" id="parking-layout" aria-live="polite" hidden></section><div class="map-legend"><span><i class="legend-available"></i>Available slot</span><span><i class="legend-occupied"></i>Occupied slot</span><span><i class="legend-full"></i>Full facility</span><span><i class="legend-closed"></i>Temporarily closed</span></div></div>`)}`;
    renderMapSlotList(facilities, "car");
    document.getElementById("show-my-location").addEventListener("click", showMyLocation);
    if (!window.L) {
        document.getElementById("module-map").innerHTML = emptyState("The interactive map is unavailable", "Parking slot counts are still available below. Check your internet connection and refresh to load the map.", "◎");
        return;
    }
    if (currentMap) currentMap.remove();
    currentMap = L.map("module-map", { zoomControl: true, scrollWheelZoom: true }).setView([20, 0], 2);
    currentMarkers = L.layerGroup().addTo(currentMap);
    currentLocationLayer = L.layerGroup().addTo(currentMap);
    const tileStatus = document.getElementById("map-tile-status");
    L.tileLayer("https://basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: "&copy; <a href=\"https://www.openstreetmap.org/copyright\">OpenStreetMap</a> &copy; <a href=\"https://carto.com/attributions\">CARTO</a>"
    })
        .on("tileerror", () => {
            tileStatus.textContent = "Map tiles could not be loaded. Slot availability is still shown below.";
            tileStatus.hidden = false;
        })
        .on("tileload", () => { tileStatus.hidden = true; })
        .addTo(currentMap);
    currentMap._parkingFacilities = facilities;
    currentMap._allFacilities = facilities;
    currentMap._parkingVehicle = "car";
    currentMap._filterVehicle = "car";
    showFacilitiesOnMap(facilities);
    document.getElementById("facility-search").addEventListener("input", filterMapFacilities);
    document.getElementById("map-vehicle").addEventListener("change", filterMapFacilities);
    document.getElementById("map-zone").addEventListener("change", filterMapFacilities);
    setTimeout(() => currentMap?.invalidateSize(), 100);
}

function showMyLocation() {
    const button = document.getElementById("show-my-location");
    const status = document.getElementById("map-location-status");
    const setStatus = (message, kind = "") => {
        if (!status) return;
        status.textContent = message;
        status.className = `map-status map-location-status${kind ? ` map-location-${kind}` : ""}`;
        status.hidden = !message;
    };
    if (!navigator.geolocation) {
        setStatus("This browser does not support location access.", "error");
        return;
    }
    if (!window.isSecureContext) {
        setStatus("Browser location requires a secure page. Open SmartPark at http://127.0.0.1:3000 on this computer, or use HTTPS.", "error");
        return;
    }
    if (!currentMap || !currentLocationLayer) {
        setStatus("The map is unavailable. Check your connection and reload before requesting your location.", "error");
        return;
    }
    if (button) button.disabled = true;
    setStatus("Requesting your location. Check the browser address bar for a permission prompt and allow access.");
    notify("Getting your location. Allow location access if your browser asks.");
    navigator.geolocation.getCurrentPosition((position) => {
        const { latitude, longitude, accuracy } = position.coords;
        currentLocationLayer.clearLayers();
        L.circle([latitude, longitude], {
            radius: accuracy,
            color: "#2563eb",
            weight: 1,
            fillColor: "#3b82f6",
            fillOpacity: 0.12
        }).addTo(currentLocationLayer);
        L.circleMarker([latitude, longitude], {
            radius: 8,
            color: "#ffffff",
            weight: 3,
            fillColor: "#2563eb",
            fillOpacity: 1
        }).bindTooltip("Your location").addTo(currentLocationLayer);
        currentMap.setView([latitude, longitude], 16);
        if (button) button.disabled = false;
        setStatus(`Your location is shown. Approximate accuracy: ${Math.round(accuracy)} m.`, "success");
        notify(`Your location is shown. Approximate accuracy: ${Math.round(accuracy)} m.`);
    }, (error) => {
        const messages = {
            1: "Location permission is blocked. Use the site controls beside the address bar to allow Location, then retry.",
            2: "The device/browser could not determine your location. Turn on device Location services and enable Wi-Fi, then retry.",
            3: "The location request timed out. Move to an area with better GPS/Wi-Fi reception and retry."
        };
        if (button) button.disabled = false;
        const message = messages[error.code] || `Could not get your location (browser error ${error.code}).`;
        setStatus(message, "error");
        notify(message, true);
    }, { enableHighAccuracy: false, timeout: 20000, maximumAge: 60000 });
}

function showFacilitiesOnMap(facilities) {
    if (!currentMarkers) return;
    currentMarkers.clearLayers();
    const visible = [];
    const vehicleType = document.getElementById("map-vehicle")?.value || "car";
    currentMap._parkingVehicle = vehicleType;
    for (const facility of facilities) {
        const inventory = facility.vehicles.find((item) => item.vehicleType === vehicleType);
        if (!inventory || !facility.active) continue;
        const marker = L.marker([facility.latitude, facility.longitude], { icon: createMarkerIcon(facility, vehicleType), title: facility.name })
            .addTo(currentMarkers)
            .on("click", () => selectFacility(facility.id, vehicleType));
        marker.bindTooltip(`${facility.name} · ${inventory.availableSpaces} available`);
        visible.push([facility.latitude, facility.longitude]);
    }
    if (visible.length === 1) currentMap.setView(visible[0], 15);
    else if (visible.length > 1) currentMap.fitBounds(L.latLngBounds(visible).pad(0.3));
}

async function filterMapFacilities() {
    const search = document.getElementById("facility-search").value.trim();
    const zone = document.getElementById("map-zone").value;
    const vehicleType = document.getElementById("map-vehicle").value;
    const params = new URLSearchParams({ vehicleType });
    if (search) params.set("q", search);
    if (zone) params.set("zone", zone);
    try {
        const facilities = await api(`/api/facilities?${params}`);
        if (currentMap && vehicleType !== currentMap._filterVehicle) {
            currentMap._allFacilities = await api(`/api/facilities?vehicleType=${encodeURIComponent(vehicleType)}`);
            currentMap._filterVehicle = vehicleType;
        }
        if (currentMap) currentMap._parkingFacilities = facilities;
        renderMapSlotList(facilities, vehicleType);
        showFacilitiesOnMap(facilities);
        if (!facilities.length) notify("No matching parking facilities were found.");
        else if (currentMap && facilities.length === 1 && search) selectFacility(facilities[0].id, vehicleType);
    } catch (error) { notify(error.message, true); }
}

function renderMapSlotList(facilities, vehicleType) {
    const heading = document.getElementById("map-slots-heading");
    const list = document.getElementById("map-slot-list");
    if (!heading || !list) return;
    heading.textContent = `${VEHICLE_NAMES[vehicleType]} parking slot availability`;
    const matchingFacilities = facilities.filter((facility) =>
        facility.vehicles.some((vehicle) => vehicle.vehicleType === vehicleType)
    );
    list.innerHTML = matchingFacilities.length
        ? `<div class="map-slot-grid">${matchingFacilities.map((facility) => {
            const inventory = facility.vehicles.find((vehicle) => vehicle.vehicleType === vehicleType);
            const available = inventory.availableSpaces;
            const state = facility.temporarilyClosed ? "Closed" : available === 0 ? "Full" : "Available";
            return `<article class="map-slot-card"><div class="map-slot-heading"><div><strong>${escapeHtml(facility.name)}</strong><span>${escapeHtml(facility.area)} · ${escapeHtml(facility.address)}</span></div>${statusBadge(state)}</div><div class="map-slot-counts"><span><strong>${COUNT.format(inventory.capacity)}</strong>Total</span><span><strong>${COUNT.format(inventory.occupiedSpaces)}</strong>Occupied</span><span><strong>${COUNT.format(inventory.reservedSpaces)}</strong>Reserved</span><span><strong>${COUNT.format(available)}</strong>Available</span></div><div class="map-slot-actions"><button class="button button-outline" type="button" data-action="show-slots" data-id="${escapeHtml(facility.id)}" data-type="${escapeHtml(vehicleType)}">View individual slots</button>${mapsDirectionsLink(facility)}</div></article>`;
        }).join("")}</div>`
        : emptyState("No matching parking facilities", "Try a different search, area, or vehicle type.");
}

function renderParkingLayout(facility, vehicleType) {
    const layout = document.getElementById("parking-layout");
    if (!layout) return;
    const inventory = facility.vehicles.find((vehicle) => vehicle.vehicleType === vehicleType);
    if (!inventory) {
        layout.hidden = false;
        layout.innerHTML = emptyState("No slots for this vehicle type", "Choose another vehicle type to view this facility's layout.");
        return;
    }
    const slots = inventory.slots || [];
    const occupied = slots.filter((slot) => slot.status === "occupied").length;
    layout.hidden = false;
    layout.innerHTML = `<div class="parking-layout-heading"><div><span class="eyebrow">INDIVIDUAL PARKING SLOTS</span><h3>${escapeHtml(facility.name)} · ${escapeHtml(VEHICLE_NAMES[vehicleType])}</h3><p>Occupied bays reflect active vehicle check-ins. Reservations are not assigned a physical bay until check-in.</p></div><span class="parking-layout-summary">${COUNT.format(occupied)} occupied · ${COUNT.format(inventory.availableSpaces)} available · ${COUNT.format(inventory.reservedSpaces)} reserved</span></div><div class="parking-bays">${slots.map((slot) => {
        const state = slot.status === "occupied" ? "occupied" : facility.temporarilyClosed ? "closed" : "available";
        const label = state === "occupied" ? "Occupied" : state === "closed" ? "Closed" : "Available";
        return `<div class="parking-bay parking-bay-${state}" title="${label}">${escapeHtml(slot.number)}<span>${label}</span></div>`;
    }).join("")}</div>`;
}

async function selectFacility(facilityId, vehicleType) {
    const facility = currentMap?._parkingFacilities?.find((item) => item.id === facilityId) || await api(`/api/facilities/${encodeURIComponent(facilityId)}`);
    selectedFacilityId = facility.id;
    renderParkingLayout(facility, vehicleType);
    const inventory = facility.vehicles.find((item) => item.vehicleType === vehicleType);
    const available = inventory?.availableSpaces || 0;
    const state = facility.temporarilyClosed ? "Closed" : available === 0 ? "Full" : "Available";
    const distanceFromCenter = currentMap ? currentMap.distance(currentMap.getCenter(), [facility.latitude, facility.longitude]) / 1000 : null;
    const nearby = (currentMap?._allFacilities || currentMap?._parkingFacilities || []).filter((item) => item.id !== facility.id && item.active && !item.temporarilyClosed && (item.vehicles.find((vehicle) => vehicle.vehicleType === vehicleType)?.availableSpaces || 0) > 0)
        .sort((left, right) => currentMap.distance([left.latitude, left.longitude], [facility.latitude, facility.longitude]) - currentMap.distance([right.latitude, right.longitude], [facility.latitude, facility.longitude]))
        .slice(0, 3);
    document.getElementById("map-detail").innerHTML = `<div class="detail-title"><div><span class="eyebrow">PARKING FACILITY</span><h3>${escapeHtml(facility.name)}</h3></div>${statusBadge(state)}</div><p class="detail-address">${escapeHtml(facility.address)} · ${escapeHtml(facility.area)}${mapsDirectionsLink(facility)}</p><div class="detail-availability"><div><strong>${COUNT.format(facility.capacity)}</strong><span>Total spaces</span></div><div><strong>${COUNT.format(facility.occupiedSpaces)}</strong><span>Occupied spaces</span></div><div><strong>${COUNT.format(facility.reservedSpaces)}</strong><span>Reserved spaces</span></div><div><strong>${COUNT.format(available)}</strong><span>${escapeHtml(VEHICLE_NAMES[vehicleType])} available</span></div></div><div class="detail-items"><div><span>Hourly ${escapeHtml(VEHICLE_NAMES[vehicleType])} rate</span><strong>${CURRENCY.format(inventory?.hourlyRate || 0)}/hr</strong></div><div><span>Daily rate</span><strong>${CURRENCY.format(inventory?.dailyRate || 0)}/day</strong></div><div><span>Operating hours</span><strong>${escapeHtml(facility.opens_at)}–${escapeHtml(facility.closes_at)}</strong></div><div><span>Distance from map centre</span><strong>${distanceFromCenter.toFixed(1)} km</strong></div><div><span>Availability updated</span><strong>${formatDate(facility.availabilityUpdatedAt)}</strong></div><div><span>Reported by</span><strong>${escapeHtml(facility.availabilitySource)}</strong></div></div>${facility.temporarilyClosed ? `<div class="alert-row alert-full"><span>!</span><strong>${escapeHtml(facility.closureReason || "This facility is temporarily closed.")}</strong></div>` : `<button class="button button-primary full-width" type="button" data-action="map-book" data-id="${escapeHtml(facility.id)}" data-type="${escapeHtml(vehicleType)}" ${available === 0 ? "disabled" : ""}>${available ? "Reserve a space" : "No spaces available"}</button>`}${available === 0 ? `<div class="detail-alternatives"><strong>Nearby alternatives</strong>${nearby.length ? nearby.map((item) => `<button class="alternative-row" type="button" data-action="map-facility" data-id="${escapeHtml(item.id)}"><span>${escapeHtml(item.name)}<small>${escapeHtml(item.area)}</small></span><strong>${COUNT.format(item.vehicles.find((v) => v.vehicleType === vehicleType).availableSpaces)} spaces · ${(currentMap.distance([item.latitude, item.longitude], [facility.latitude, facility.longitude]) / 1000).toFixed(1)} km</strong></button>`).join("") : `<p>No nearby alternatives found for ${escapeHtml(VEHICLE_NAMES[vehicleType])}.</p>`}</div>` : ""}`;
}

function renderOperations(sessions) {
    const active = sessions.filter((session) => session.status === "parked");
    const rowsHtml = active.length ? `<div class="table-wrap"><table><thead><tr><th>Registration</th><th>Facility</th><th>Vehicle</th><th>Space</th><th>Entry time</th><th>Expected exit</th><th>Overstay</th><th>Action</th></tr></thead><tbody>${active.map((session) => {
        const overdue = session.expected_exit_at && Date.parse(session.expected_exit_at) < Date.now();
        return `<tr><td><strong>${escapeHtml(session.plate)}</strong></td><td>${escapeHtml(session.facility_name)}</td><td>${escapeHtml(VEHICLE_NAMES[session.vehicle_type])}</td><td>${escapeHtml(session.space_number)}</td><td>${formatDate(session.entered_at)}</td><td>${formatDate(session.expected_exit_at)}</td><td>${overdue ? statusBadge("overstay") : "—"}</td><td>${actionButton("Record exit", "vehicle-exit", session.id, overdue ? "button-danger" : "button-outline")}</td></tr>`;
    }).join("")}</tbody></table></div>` : emptyState("No vehicles currently parked", "Record a vehicle entry or check a customer reservation into a parking space.", "↗");
    content.innerHTML = `${pageIntro("Parking operations", "Record arrivals and departures, allocate spaces, check in bookings, and monitor vehicles.", "Record vehicle entry", "entry")}<div class="summary-strip"><span>${COUNT.format(active.length)}<small>vehicles on site</small></span><span>${COUNT.format(active.filter((session) => session.expected_exit_at && Date.parse(session.expected_exit_at) < Date.now()).length)}<small>overstay alerts</small></span><span>Live<small>physical occupancy is separate from reservations</small></span></div>${panel("On-site vehicles", "Entry and exit records update physical occupancy and availability immediately.", rowsHtml, `<button type="button" class="button button-outline" data-action="checkin">Check in a booking</button>`)}${panel("How availability is calculated", "", `<div class="info-callout"><span>i</span><p>Available spaces = capacity − physically parked vehicles − confirmed future reservations. Checking a booking in releases its reservation and records one physical vehicle, so a space is never counted twice.</p></div>`)}`;
}

function renderBusinessConfig(facilities) {
    content.innerHTML = `${pageIntro("Facility configuration", "Manage parking locations, vehicle-specific capacity, pricing, access rules, and temporary closures.", "Add facility", "new-facility")}<div class="summary-strip"><span>${COUNT.format(facilities.filter((facility) => facility.active).length)}<small>active facilities</small></span><span>${COUNT.format(facilities.filter((facility) => facility.temporarilyClosed).length)}<small>temporary closures</small></span><span>Per vehicle<small>independent capacity and pricing rules</small></span></div>${panel("Facility directory", "Update addresses, GPS coordinates, capacity, tariffs and operating hours.", facilityTable(facilities, true))}`;
}

function renderBookings(bookings, facilities) {
    const operator = ["administrator", "parking operator"].includes(currentUser?.role);
    const rowsHtml = bookings.length ? `<div class="table-wrap"><table><thead><tr><th>Booking reference</th><th>Customer</th><th>Facility</th><th>Vehicle / reg.</th><th>Parking period</th><th>Fee</th><th>Payment</th><th>Status</th><th>Actions</th></tr></thead><tbody>${bookings.map((booking) => `<tr><td><strong>${escapeHtml(booking.id)}</strong></td><td>${escapeHtml(booking.customer_name)}<span class="table-sub">${escapeHtml(booking.customer_email)}</span></td><td>${escapeHtml(booking.facility_name)}</td><td>${escapeHtml(VEHICLE_NAMES[booking.vehicle_type])}<span class="table-sub">${escapeHtml(booking.plate || "Reservation pending check-in")}</span></td><td>${formatDate(booking.starts_at)}<span class="table-sub">until ${formatDate(booking.ends_at)}</span></td><td>${CURRENCY.format(booking.fee)}</td><td>${statusBadge(booking.payment_status || "pending")}</td><td>${statusBadge(booking.status)}</td><td class="table-actions">${operator && booking.status === "confirmed" ? actionButton("Check in", "booking-checkin", booking.id, "button-outline") : ""}${["confirmed", "pending"].includes(booking.status) ? actionButton("Cancel", "booking-cancel", booking.id, "button-quiet") : ""}</td></tr>`).join("")}</tbody></table></div>` : emptyState("No reservations yet", "New reservations, confirmations, check-ins and cancellations will appear here.", "▤");
    const canBook = currentUser?.role !== "parking operator";
    content.innerHTML = `${pageIntro("Reservations & business processing", "Manage bookings from capacity checks and confirmations through check-in, cancellation and payment.", canBook ? "Create reservation" : "", canBook ? "new-booking" : "")}<div class="summary-strip"><span>${COUNT.format(bookings.filter((b) => b.status === "confirmed").length)}<small>confirmed bookings</small></span><span>${COUNT.format(bookings.filter((b) => b.status === "checked_in").length)}<small>currently checked in</small></span><span>${COUNT.format(bookings.filter((b) => b.status === "cancelled").length)}<small>cancelled bookings</small></span></div>${panel("Booking register", "Availability is reserved when a booking is confirmed; cancellation releases capacity.", rowsHtml)}<div hidden id="facility-options">${facilities.map((facility) => `<option value="${escapeHtml(facility.id)}">${escapeHtml(facility.name)}</option>`).join("")}</div>`;
}

function renderParkingData(facilities) {
    const updates = facilities.length ? `<div class="table-wrap"><table><thead><tr><th>Parking facility</th><th>Vehicle type</th><th>Capacity</th><th>Occupied</th><th>Reserved</th><th>Available</th><th>Availability source / updated</th><th>Actions</th></tr></thead><tbody>${facilities.flatMap((facility) => facility.vehicles.map((vehicle) => `<tr><td><strong>${escapeHtml(facility.name)}</strong><span class="table-sub">${escapeHtml(facility.address)}</span></td><td><span class="type-chip">${escapeHtml(VEHICLE_NAMES[vehicle.vehicleType])}</span></td><td>${COUNT.format(vehicle.capacity)}</td><td>${COUNT.format(vehicle.occupiedSpaces)}</td><td>${COUNT.format(vehicle.reservedSpaces)}</td><td><strong>${COUNT.format(vehicle.availableSpaces)}</strong></td><td>${escapeHtml(facility.availabilitySource)}<span class="table-sub">${formatDate(facility.availabilityUpdatedAt)}</span></td><td>${actionButton("Update count", "edit-availability", facility.id, "button-outline", `data-type="${escapeHtml(vehicle.vehicleType)}"`)}</td></tr>`)).join("")}</tbody></table></div>` : emptyState("No parking records", "Add a facility in Business Config to start storing inventory.");
    content.innerHTML = `${pageIntro("Parking data", "Search and audit facility records, per-vehicle occupancy, availability sources, and update timestamps.", "Export CSV", "export-data")}<div class="toolbar-inline"><label class="search-input"><span>⌕</span><input type="search" id="parking-search" placeholder="Search name, zone, landmark or address" aria-label="Search parking records"></label><label class="checkbox-control"><input type="checkbox" id="include-inactive"><span>Include inactive facilities</span></label></div>${panel("Availability records", "Physical occupancy, future reservations and remaining capacity are tracked independently.", updates)}`;
}

function renderMessages(notifications) {
    const unread = notifications.filter((item) => item.status === "unread").length;
    const rowsHtml = notifications.length ? `<div class="notification-list">${notifications.map((item) => `<article class="notification-row ${item.status === "unread" ? "notification-unread" : ""}"><div class="notification-symbol">${item.title.toLowerCase().includes("cancel") ? "↩" : item.title.toLowerCase().includes("full") ? "!" : "✉"}</div><div class="notification-copy"><div class="notification-head"><strong>${escapeHtml(item.title)}</strong>${statusBadge(item.status)}</div><p>${escapeHtml(item.message)}</p><span>${escapeHtml(item.recipient)} · ${formatDate(item.created_at)}</span></div>${item.status === "unread" ? actionButton("Mark read", "read-notification", item.id) : ""}</article>`).join("")}</div>` : emptyState("Your message center is clear", "Booking confirmations, operator alerts, and announcements show up here.", "✉");
    const canSend = currentUser?.role !== "customer";
    content.innerHTML = `${pageIntro("Message center", "Send website notifications, review booking messages and notify operators of closures or availability issues.", canSend ? "Send announcement" : "", canSend ? "new-message" : "")}<div class="summary-strip"><span>${COUNT.format(unread)}<small>unread notifications</small></span><span>Website<small>notifications are delivered in this workspace</small></span><span>No SMS<small>external message delivery is not configured</small></span></div>${panel("Notifications", "Confirmation, cancellation, operations and announcement history.", rowsHtml)}`;
}

function renderSupport(requests, facilities) {
    const statuses = ["open", "in_progress", "resolved", "rejected"];
    const operator = ["administrator", "parking operator"].includes(currentUser?.role);
    const rowsHtml = requests.length ? `<div class="support-list">${requests.map((request) => `<article class="support-card"><div class="support-header"><span class="support-category">${escapeHtml(request.category)}</span>${statusBadge(request.status)}</div><h3>${escapeHtml(request.subject)}</h3><p>${escapeHtml(request.message)}</p><div class="support-meta"><span>${escapeHtml(request.customer_name)}${request.customer_email ? ` · ${escapeHtml(request.customer_email)}` : ""}</span><span>${escapeHtml(request.facility_name || "General enquiry")} · ${formatDate(request.created_at)}</span></div>${operator ? `<div class="support-controls"><label>Assign to <input type="text" id="assignee-${escapeHtml(request.id)}" value="${escapeHtml(request.assigned_to)}"></label><label>Update status <select id="support-status-${escapeHtml(request.id)}">${statuses.map((status) => `<option value="${status}" ${request.status === status ? "selected" : ""}>${escapeHtml(status.replace("_", " "))}</option>`).join("")}</select></label><label>Rating <select id="support-rating-${escapeHtml(request.id)}"><option value="">Not rated</option>${[1, 2, 3, 4, 5].map((rating) => `<option value="${rating}" ${request.rating === rating ? "selected" : ""}>${rating} ★</option>`).join("")}</select></label><button class="button button-outline" type="button" data-action="update-support" data-id="${escapeHtml(request.id)}">Save update</button></div>` : request.status === "resolved" && !request.rating ? `<button class="button button-outline" type="button" data-action="rate-support" data-id="${escapeHtml(request.id)}">Rate your support experience</button>` : request.rating ? `<span class="support-meta">Customer rating: ${request.rating} ★</span>` : ""}</article>`).join("")}</div>` : emptyState("No customer service requests", "When customers report a problem, their cases appear here.", "♧");
    content.innerHTML = `${pageIntro("Customer service", "Track availability, location, reservation and payment issues from report to resolution.", "Record customer issue", "new-support")}<div class="summary-strip"><span>${COUNT.format(requests.filter((item) => item.status === "open").length)}<small>open cases</small></span><span>${COUNT.format(requests.filter((item) => item.status === "in_progress").length)}<small>in progress</small></span><span>${COUNT.format(requests.filter((item) => item.status === "resolved").length)}<small>resolved</small></span></div>${panel("Customer support cases", "Assign an operator, update issue status and save customer feedback.", rowsHtml)}<div hidden id="support-facilities">${facilities.map((facility) => `<option value="${escapeHtml(facility.id)}">${escapeHtml(facility.name)}</option>`).join("")}</div>`;
}

function renderStatistics(stats) {
    const maxValue = Math.max(1, ...stats.daily.map((day) => day.bookings));
    const chart = stats.daily.length
        ? `<div class="bar-chart">${stats.daily.map((day) => `<div class="chart-column"><span class="chart-value">${COUNT.format(day.bookings)}</span><div class="chart-bars"><i style="height:${Math.max(3, Math.round(day.bookings / maxValue * 100))}%" title="${COUNT.format(day.bookings)} bookings"></i><i class="cancel-bar" style="height:${Math.max(2, Math.round(day.cancellations / maxValue * 100))}%" title="${COUNT.format(day.cancellations)} cancellations"></i></div><span class="chart-label">${escapeHtml(new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(new Date(`${day.date}T12:00:00`)))}</span></div>`).join("")}</div><div class="chart-legend"><span>Bookings</span><span>Cancellations</span></div>`
        : emptyState("Waiting for booking activity", "Real chart data will appear as customers make reservations.", "▥");
    const vehicleRows = stats.byType.map((row) => `<div class="bar-row"><span>${escapeHtml(VEHICLE_NAMES[row.vehicleType])}</span><div class="horizontal-track"><span style="width:${row.capacity ? Math.min(100, row.occupied / row.capacity * 100) : 0}%"></span></div><strong>${row.capacity ? Math.round(row.occupied / row.capacity * 100) : 0}%</strong><small>${COUNT.format(row.occupied)} / ${COUNT.format(row.capacity)}</small></div>`).join("");
    const popular = stats.mostPopular.map((facility) => `<div class="recent-row"><span class="recent-pin">◎</span><span><strong>${escapeHtml(facility.name)}</strong><span>Confirmed reservations</span></span><strong>${COUNT.format(facility.bookings)}</strong></div>`).join("");
    content.innerHTML = `${pageIntro("Parking analytics", "Measure actual reservation demand, occupancy, vehicle mix and cancellation trends.", "", "")}<div class="toolbar-inline"><label class="select-field"><span>REPORT PERIOD</span><select id="statistics-period"><option value="day" ${stats.period === "day" ? "selected" : ""}>Today</option><option value="week" ${stats.period === "week" ? "selected" : ""}>Last 7 days</option><option value="month" ${stats.period === "month" ? "selected" : ""}>Last 30 days</option></select></label></div><div class="metric-grid metric-grid-three"><article class="metric-card"><span class="metric-label">Network occupancy</span><strong>${stats.occupancyRate}%</strong><span class="metric-helper">${COUNT.format(stats.occupiedSpaces)} physically occupied · ${COUNT.format(stats.reservedSpaces)} reserved</span></article><article class="metric-card"><span class="metric-label">Active reservations</span><strong>${COUNT.format(stats.activeBookings)}</strong><span class="metric-helper">Pending, confirmed or checked in</span></article><article class="metric-card"><span class="metric-label">Facility demand</span><strong>${COUNT.format(stats.totalFacilities)}</strong><span class="metric-helper">Across registered active facilities</span></article></div><div class="dashboard-grid"><div>${panel("Reservation activity", "Real reservation counts by booking creation day; no activity is fabricated.", chart)}${panel("Usage by vehicle type", "Occupied physical spaces compared with configured capacity.", vehicleRows ? `<div class="bar-list">${vehicleRows}</div>` : emptyState("No vehicle inventory", "Configure per-vehicle spaces in Business Config."))}</div><aside>${panel("Most-booked facilities", "Ranked using recorded reservations.", popular || emptyState("No recorded reservations", "Facility rankings will appear after customers make bookings."))}<div class="info-callout"><span>i</span><p>Usage statistics describe data actually recorded in SmartPark. A dashboard alone does not establish a reduction in traffic; that claim requires measured pilot data.</p></div></aside></div>`;
}

function renderFinance(transactions, facilities, settings) {
    const completed = transactions.filter((transaction) => transaction.status === "completed").reduce((total, transaction) => total + transaction.amount, 0);
    const outstanding = transactions.filter((transaction) => transaction.status === "pending").reduce((total, transaction) => total + transaction.amount, 0);
    const refunded = transactions.filter((transaction) => transaction.status === "refunded").reduce((total, transaction) => total + transaction.amount, 0);
    const rowsHtml = transactions.length ? `<div class="table-wrap"><table><thead><tr><th>Payment reference</th><th>Date</th><th>Customer</th><th>Facility</th><th>Charge</th><th>Method</th><th>Status</th><th>Payment action</th></tr></thead><tbody>${transactions.map((transaction) => `<tr><td><strong>${escapeHtml(transaction.id)}</strong><span class="table-sub">${escapeHtml(transaction.description)}</span></td><td>${formatDate(transaction.created_at)}</td><td>${escapeHtml(transaction.customer_name)}</td><td>${escapeHtml(transaction.facility_name)}</td><td><strong>${CURRENCY.format(transaction.amount)}</strong></td><td>${escapeHtml(transaction.payment_method)}</td><td>${statusBadge(transaction.status)}</td><td>${["pending", "failed"].includes(transaction.status) ? actionButton("Mark paid", "payment-paid", transaction.id) : ""}${transaction.status === "completed" ? actionButton("Refund", "payment-refund", transaction.id, "button-quiet") : ""}</td></tr>`).join("")}</tbody></table></div>` : emptyState("No payment records yet", "Reservation charges and parking session fees will be recorded here.", "₹");
    const tariffList = facilities.flatMap((facility) => facility.vehicles.map((vehicle) => `<div class="tariff-row"><span><strong>${escapeHtml(facility.name)} · ${escapeHtml(VEHICLE_NAMES[vehicle.vehicleType])}</strong><small>${escapeHtml(facility.zone)}</small></span><span>${CURRENCY.format(vehicle.hourlyRate)}/hr · ${CURRENCY.format(vehicle.dailyRate)}/day</span>${actionButton("Edit tariff", "edit-tariff", facility.id, "button-outline", `data-type="${escapeHtml(vehicle.vehicleType)}"`)}</div>`)).join("");
    content.innerHTML = `${pageIntro("Finance & payments", "Review parking tariffs, simulated payment records, completed revenue and refunds.", "Download payment report", "export-payments")}<div class="metric-grid metric-grid-three"><article class="metric-card"><span class="metric-label">Completed revenue</span><strong>${CURRENCY.format(completed)}</strong><span class="metric-helper">${COUNT.format(transactions.filter((item) => item.status === "completed").length)} settled payments</span></article><article class="metric-card"><span class="metric-label">Pending payments</span><strong>${CURRENCY.format(outstanding)}</strong><span class="metric-helper">Simulated payments awaiting settlement</span></article><article class="metric-card"><span class="metric-label">Refunds recorded</span><strong>${CURRENCY.format(refunded)}</strong><span class="metric-helper">Completed refunds and adjustments</span></article></div>${panel("Payment ledger", "Reservation preauthorizations and exit charges can be marked paid or refunded.", rowsHtml)}${panel("Facility tariffs", "Adjust hourly and daily tariffs for parking facilities.", tariffList || emptyState("No facilities configured", "Set up a facility before configuring tariffs."))}<div class="info-callout"><span>i</span><p>Payments are simulated; this prototype does not connect to a payment gateway. Booking charges are calculated from facility hourly and daily tariffs.</p></div>`;
}

function renderSystem(users, settings, logs, facilities, resetRequests) {
    const settingsRows = settings.map((setting) => `<label class="setting-row"><span><strong>${escapeHtml(setting.key.replace(/([A-Z])/g, " $1").replace(/^\w/, (c) => c.toUpperCase()))}</strong><small>Updated ${formatDate(setting.updatedAt)}</small></span><span class="setting-input"><input type="text" name="${escapeHtml(setting.key)}" value="${escapeHtml(setting.value)}"><button type="button" class="button button-outline" data-action="save-setting" data-id="${escapeHtml(setting.key)}">Save</button></span></label>`).join("");
    const userRows = users.length ? `<div class="table-wrap"><table><thead><tr><th>Team member</th><th>Access role</th><th>Assigned facility</th><th>Account</th><th>Change access</th></tr></thead><tbody>${users.map((user) => `<tr><td><strong>${escapeHtml(user.name)}</strong><span class="table-sub">${escapeHtml(user.email)}</span></td><td>${escapeHtml(user.role)}</td><td>${escapeHtml(facilities.find((facility) => facility.id === user.facility_id)?.name || "All facilities")}</td><td>${statusBadge(user.status)}</td><td>${actionButton(user.status === "active" ? "Deactivate" : "Activate", "toggle-user", user.id)}<button type="button" class="text-button" data-action="edit-user-role" data-id="${escapeHtml(user.id)}">Change role</button></td></tr>`).join("")}</tbody></table></div>` : emptyState("No team accounts registered", "Create administrator, operator and customer role records.", "♧");
    const logList = logs.length ? `<div class="activity-list">${logs.map((log) => `<div class="activity-row"><span class="activity-icon">·</span><span><strong>${escapeHtml(log.action)} · ${escapeHtml(log.entity_type)}</strong><small>${escapeHtml(log.details)}</small></span><span>${formatDate(log.created_at)}</span></div>`).join("")}</div>` : emptyState("No changes have been recorded", "Configuration and operational changes are recorded for administrator review.", "▤");
    const resetRows = resetRequests.length ? `<div class="activity-list">${resetRequests.map((request) => `<div class="activity-row"><span class="activity-icon">↻</span><span><strong>Password-reset request${statusBadge(request.status)}</strong><small>${escapeHtml(request.email)}</small></span><span>${formatDate(request.created_at)}${request.status === "pending" ? actionButton("Issue 30-minute code", "issue-reset", request.email, "button-outline") : ""}</span></div>`).join("")}</div>` : emptyState("No pending password-reset requests", "Customer-initiated password recovery requests will appear here.", "↻");
    content.innerHTML = `${pageIntro("System management", "Manage the workspace, securely authenticate team members, assign facility-scoped roles and review the audit trail.", "Add team member", "new-user")}<div class="info-callout"><span>i</span><p>Password-protected sign-in and server-enforced role permissions are active. New-account invitation codes and administrator-issued recovery codes expire after 30 minutes and are shown only once. Deliver them to the intended person using your approved private channel.</p></div><div class="dashboard-grid"><div>${panel("Team &amp; access roles", "Administrator, facility-scoped parking operator and customer account directory.", userRows)}${panel("Password-reset requests", "Verify a user's identity before issuing a time-limited password-reset code.", resetRows)}${panel("Role guide", "", `<div class="role-grid"><div><strong>Administrator</strong><p>System configuration, facilities, accounts, finance, reports and password resets.</p></div><div><strong>Parking operator</strong><p>Availability, vehicle movements, and customer cases for their assigned facility only.</p></div><div><strong>Customer</strong><p>Parking search, their own reservations, booking cancellations and support cases.</p></div></div>`)}</div><aside>${panel("Application settings", "Values are saved to the persistent database.", `<div class="settings-list">${settingsRows}</div>`)}${panel("Recent audit history", "Recorded facility, availability, booking and administrative changes.", logList)}</aside></div>`;
}

async function renderModule(moduleName) {
    currentModule = MODULE_NAMES[moduleName] ? moduleName : "home";
    document.querySelectorAll(".nav-link[data-module]").forEach((link) => {
        const active = link.dataset.module === currentModule;
        link.classList.toggle("active", active);
        if (active) link.setAttribute("aria-current", "page");
        else link.removeAttribute("aria-current");
    });
    document.getElementById("page-title").textContent = MODULE_NAMES[currentModule];
    if (currentMap) {
        currentMap.remove();
        currentMap = null;
        currentMarkers = null;
    }
    content.innerHTML = `<div class="loading-state"><span class="loading-spinner"></span>Loading ${escapeHtml(MODULE_NAMES[currentModule])} from the database…</div>`;
    try {
        if (currentModule === "home") renderHome(await api("/api/home"));
        else if (currentModule === "map") await renderMap();
        else if (currentModule === "operations") renderOperations(await api("/api/operations"));
        else if (currentModule === "business-config") renderBusinessConfig(await api("/api/facilities?includeInactive=true"));
        else if (currentModule === "business-processing") {
            const [bookings, facilities] = await Promise.all([api("/api/bookings"), api("/api/facilities")]);
            renderBookings(bookings, facilities);
        } else if (currentModule === "parking-data") renderParkingData(await api("/api/parking-data"));
        else if (currentModule === "message-center") renderMessages(await api("/api/notifications"));
        else if (currentModule === "customer-service") {
            const [requests, facilities] = await Promise.all([api("/api/support"), api("/api/facilities")]);
            renderSupport(requests, facilities);
        } else if (currentModule === "statistics") renderStatistics(await api(`/api/stats?period=${encodeURIComponent(new URLSearchParams(location.hash.slice(1).split("?")[1] || "").get("period") || "week")}`));
        else if (currentModule === "finance") {
            const [payments, facilities, settings] = await Promise.all([api("/api/transactions"), api("/api/facilities"), api("/api/settings")]);
            renderFinance(payments, facilities, settings);
        } else if (currentModule === "system-management") {
            const [users, settings, logs, facilities, resetRequests] = await Promise.all([api("/api/users"), api("/api/settings"), api("/api/audit"), api("/api/facilities?includeInactive=true"), api("/api/password-reset-requests")]);
            renderSystem(users, settings, logs, facilities, resetRequests);
        }
    } catch (error) {
        content.innerHTML = `<div class="error-state"><span>!</span><h2>Could not load ${escapeHtml(MODULE_NAMES[currentModule])}</h2><p>${escapeHtml(error.message)}</p><button type="button" class="button button-outline" data-action="retry">Try again</button></div>`;
        notify(error.message, true);
    }
}

function fieldMarkup(field) {
    const id = `field-${field.name}`;
    const required = field.required ? "required" : "";
    const placeholder = field.placeholder ? `placeholder="${escapeHtml(field.placeholder)}"` : "";
    const help = field.help ? `<small class="field-help">${escapeHtml(field.help)}</small>` : "";
    let input;
    if (field.type === "select") {
        input = `<select id="${id}" name="${escapeHtml(field.name)}" ${required}>${field.placeholder ? `<option value="">${escapeHtml(field.placeholder)}</option>` : ""}${field.options.map((option) => `<option value="${escapeHtml(option.value)}" ${String(field.value) === String(option.value) ? "selected" : ""}>${escapeHtml(option.label)}</option>`).join("")}</select>`;
    } else if (field.type === "textarea") {
        input = `<textarea id="${id}" name="${escapeHtml(field.name)}" rows="${field.rows || 3}" ${required} ${placeholder}>${escapeHtml(field.value ?? "")}</textarea>`;
    } else if (field.type === "checkbox") {
        input = `<label class="toggle-field"><input id="${id}" name="${escapeHtml(field.name)}" type="checkbox" ${field.value ? "checked" : ""}><span>${escapeHtml(field.checkboxLabel || field.label)}</span></label>`;
    } else {
        const type = field.type || "text";
        const step = field.step ? `step="${escapeHtml(field.step)}"` : "";
        const min = field.min !== undefined ? `min="${escapeHtml(field.min)}"` : "";
        const max = field.max !== undefined ? `max="${escapeHtml(field.max)}"` : "";
        input = `<input id="${id}" name="${escapeHtml(field.name)}" type="${escapeHtml(type)}" ${required} ${placeholder} ${step} ${min} ${max} value="${escapeHtml(field.value ?? "")}" ${field.readonly ? "readonly" : ""}>`;
    }
    return `<label class="form-field ${field.wide ? "field-wide" : ""}" for="${field.type === "checkbox" ? "" : id}"><span>${escapeHtml(field.label)}${field.required ? ' <b>*</b>' : ""}</span>${input}${help}</label>`;
}

function showForm(title, fields, onSubmit, submitLabel = "Save changes") {
    modalSubmit = onSubmit;
    document.getElementById("modal-title").textContent = title;
    document.getElementById("modal-submit").textContent = submitLabel;
    document.getElementById("form-error").hidden = true;
    formFields.innerHTML = fields.map(fieldMarkup).join("");
    formDialog.showModal();
}

function readFormFields(fields) {
    const result = {};
    for (const field of fields) {
        const element = document.getElementById(`field-${field.name}`);
        if (!element) continue;
        if (field.type === "checkbox") result[field.name] = element.checked;
        else if (field.type === "number") result[field.name] = element.value === "" ? 0 : Number(element.value);
        else if (field.type === "datetime-local") result[field.name] = element.value ? new Date(element.value).toISOString() : "";
        else result[field.name] = element.value.trim();
    }
    return result;
}

function facilityFields(facility) {
    const currentCapacities = Object.fromEntries((facility?.vehicles || []).map((item) => [item.vehicleType, item.capacity]));
    const fields = [
        { name: "name", label: "Facility name", required: true, value: facility?.name || "" },
        { name: "zone", label: "Zone", required: true, value: facility?.zone || "", placeholder: "For example: East Coast" },
        { name: "address", label: "Street address", required: true, value: facility?.address || "", wide: true },
        { name: "city", label: "City", value: facility?.city || "" },
        { name: "area", label: "Area / neighbourhood", required: true, value: facility?.area || "" },
        { name: "landmark", label: "Nearby landmark", value: facility?.landmark || "" },
        { name: "latitude", label: "Map latitude", type: "number", step: "any", required: true, value: facility?.latitude ?? "" },
        { name: "longitude", label: "Map longitude", type: "number", step: "any", required: true, value: facility?.longitude ?? "" },
        ...VEHICLE_TYPES.flatMap((type) => {
            const existing = facility?.vehicles.find((item) => item.vehicleType === type);
            return [
                { name: `capacity-${type}`, label: `${VEHICLE_NAMES[type]} spaces`, type: "number", min: "0", step: "1", value: currentCapacities[type] || 0 },
                { name: `hourly-${type}`, label: `${VEHICLE_NAMES[type]} hourly rate (₹)`, type: "number", min: "0", step: "0.01", value: existing?.hourlyRate ?? facility?.hourlyRate ?? 0 },
                { name: `daily-${type}`, label: `${VEHICLE_NAMES[type]} daily rate (₹)`, type: "number", min: "0", step: "0.01", value: existing?.dailyRate ?? facility?.dailyRate ?? 0 }
            ];
        }),
        { name: "opensAt", label: "Opening time", type: "time", value: facility?.opens_at || "00:00" },
        { name: "closesAt", label: "Closing time", type: "time", value: facility?.closes_at || "23:59" },
        { name: "gracePeriodMinutes", label: "Grace period (minutes)", type: "number", min: "0", value: facility?.grace_period_minutes ?? 15 },
        { name: "cancellationHours", label: "Free cancellation cutoff (hours)", type: "number", min: "0", value: facility?.cancellation_hours ?? 2 },
        { name: "restrictions", label: "Vehicle size restrictions", type: "textarea", wide: true, value: facility?.restrictions || "" },
        { name: "operatingHours", label: "Weekly operating hours (JSON)", type: "textarea", wide: true, rows: 3, value: JSON.stringify(facility?.operatingHours || {}, null, 2), help: 'Optional day schedule, for example {"monday":"06:00-22:00"}. The daily opening and closing fields above remain the default.' },
        { name: "holidaySchedule", label: "Holiday schedules (JSON)", type: "textarea", wide: true, rows: 3, value: JSON.stringify(facility?.holidaySchedule || [], null, 2), help: 'An array of closure dates or holiday opening times, for example [{"date":"2026-12-25","closed":true}].' }
    ];
    if (facility) fields.push({ name: "temporarilyClosed", label: "Temporary closure", type: "checkbox", checkboxLabel: "Temporarily close this facility", value: facility.temporarilyClosed }, { name: "closureReason", label: "Closure reason", value: facility.closureReason || "" });
    return fields;
}

function defaultDatetime(hours) {
    const date = new Date(Date.now() + hours * 3600000);
    date.setMinutes(date.getMinutes() - date.getTimezoneOffset());
    return date.toISOString().slice(0, 16);
}

function openBookingForm(facilityId = "", vehicleType = "car") {
    api("/api/facilities").then((facilities) => {
        const availableFacilities = facilities.filter((facility) => facility.vehicles.some((item) => item.vehicleType === vehicleType && item.availableSpaces > 0) || facility.id === facilityId);
        const fields = [
            { name: "customerName", label: "Customer name", required: true, value: currentUser?.role === "customer" ? currentUser.name : "", readonly: currentUser?.role === "customer" },
            { name: "customerEmail", label: "Customer email", type: "email", value: currentUser?.role === "customer" ? currentUser.email : "", placeholder: "For your in-app confirmation", readonly: currentUser?.role === "customer" },
            { name: "facilityId", label: "Parking facility", type: "select", required: true, value: facilityId, options: availableFacilities.map((item) => ({ value: item.id, label: `${item.name} (${item.availableSpaces} free)` })) },
            { name: "vehicleType", label: "Vehicle type", type: "select", required: true, value: vehicleType, options: VEHICLE_TYPES.map((type) => ({ value: type, label: VEHICLE_NAMES[type] })) },
            { name: "startsAt", label: "Arrival", type: "datetime-local", required: true, value: defaultDatetime(1) },
            { name: "endsAt", label: "Departure", type: "datetime-local", required: true, value: defaultDatetime(3) },
            { name: "paymentMethod", label: "Payment method", type: "select", options: ["Cash", "Card (simulated)", "UPI (simulated)"].map((label) => ({ value: label, label })) }
        ];
        showForm("Create parking reservation", fields, async () => {
            const payload = readFormFields(fields);
            const booking = await api("/api/bookings", { method: "POST", body: payload });
            notify(`Reservation ${booking.id} confirmed. Fee: ${CURRENCY.format(booking.fee)}.`);
            await refreshNotifications();
            await renderModule(currentModule);
        }, "Confirm reservation");
    }).catch((error) => notify(error.message, true));
}

function openEntryForm(bookingId = "") {
    Promise.all([api("/api/facilities"), api("/api/bookings")]).then(([facilities, bookings]) => {
        const confirmed = bookings.filter((booking) => booking.status === "confirmed");
        const facilityOptions = facilities.map((facility) => ({ value: facility.id, label: `${facility.name} (${facility.availableSpaces} available)` }));
        const fields = [
            ...(bookingId ? [{ name: "bookingId", label: "Confirmed reservation", type: "select", required: true, value: bookingId, options: confirmed.map((booking) => ({ value: booking.id, label: `${booking.id} · ${booking.customer_name} · ${booking.facility_name}` })) }] : []),
            { name: "facilityId", label: "Parking facility", type: "select", required: true, options: facilityOptions },
            { name: "vehicleType", label: "Vehicle type", type: "select", required: true, options: VEHICLE_TYPES.map((type) => ({ value: type, label: VEHICLE_NAMES[type] })) },
            { name: "plate", label: "Vehicle registration", required: true, placeholder: "e.g. ABC 1234" },
            { name: "expectedExitAt", label: "Expected exit", type: "datetime-local", value: defaultDatetime(2) }
        ];
        showForm(bookingId ? "Check in customer reservation" : "Record vehicle entry", fields, async () => {
            const payload = readFormFields(fields);
            const result = payload.bookingId
                ? await api(`/api/bookings/${encodeURIComponent(payload.bookingId)}/check-in`, { method: "POST", body: payload })
                : await api("/api/operations/entry", { method: "POST", body: payload });
            notify(`Vehicle ${result.plate} assigned space ${result.space_number}.`);
            await renderModule(currentModule);
        }, bookingId ? "Check in vehicle" : "Record entry");
    }).catch((error) => notify(error.message, true));
}

async function openFacilityForm(facility = null) {
    const fields = facilityFields(facility);
    showForm(facility ? "Edit parking facility" : "Register a parking facility", fields, async () => {
        const result = readFormFields(fields);
        result.capacities = Object.fromEntries(VEHICLE_TYPES.map((type) => [type, result[`capacity-${type}`]]));
        result.tariffs = Object.fromEntries(VEHICLE_TYPES.filter((type) => result.capacities[type] > 0).map((type) => [type, { hourlyRate: result[`hourly-${type}`], dailyRate: result[`daily-${type}`] }]));
        for (const type of VEHICLE_TYPES) {
            delete result[`capacity-${type}`];
            delete result[`hourly-${type}`];
            delete result[`daily-${type}`];
        }
        try {
            result.operatingHours = JSON.parse(result.operatingHours);
            result.holidaySchedule = JSON.parse(result.holidaySchedule);
        } catch { throw new Error("Weekly hours and holiday schedules must contain valid JSON."); }
        await api(facility ? `/api/facilities/${encodeURIComponent(facility.id)}` : "/api/facilities", { method: facility ? "PATCH" : "POST", body: result });
        notify(facility ? "Facility configuration saved." : "Parking facility registered.");
        await renderModule(currentModule);
    }, facility ? "Save facility" : "Register facility");
}

function openSupportForm() {
    api("/api/facilities").then((facilities) => {
        const fields = [
            { name: "customerName", label: "Customer name", required: true, value: currentUser?.role === "customer" ? currentUser.name : "", readonly: currentUser?.role === "customer" },
            { name: "customerEmail", label: "Contact email", type: "email", value: currentUser?.role === "customer" ? currentUser.email : "", readonly: currentUser?.role === "customer" },
            { name: "category", label: "Issue type", type: "select", required: true, options: ["Availability", "Pricing", "Incorrect location", "Reservation", "Payment", "Facility closure", "Other"].map((item) => ({ value: item, label: item })) },
            { name: "facilityId", label: "Related facility", type: "select", options: [{ value: "", label: "No specific facility" }, ...facilities.map((item) => ({ value: item.id, label: item.name }))] },
            { name: "subject", label: "Issue title", required: true, wide: true },
            { name: "message", label: "Describe the problem", type: "textarea", required: true, wide: true }
        ];
        showForm("Create customer support case", fields, async () => {
            const result = await api("/api/support", { method: "POST", body: readFormFields(fields) });
            notify(`Support case ${result.id} has been recorded.`);
            await renderModule(currentModule);
        }, "Submit support case");
    }).catch((error) => notify(error.message, true));
}

function handleAction(event) {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    event.preventDefault();
    const { action, id, type } = button.dataset;
    const run = async () => {
        if (action === "retry") return renderModule(currentModule);
        if (action === "new-facility") return openFacilityForm();
        if (action === "edit-facility") return openFacilityForm(await api(`/api/facilities/${encodeURIComponent(id)}`));
        if (action === "toggle-facility") {
            const facility = await api(`/api/facilities/${encodeURIComponent(id)}`);
            await api(`/api/facilities/${encodeURIComponent(id)}`, { method: "PATCH", body: { active: !facility.active } });
            notify(facility.active ? "Facility deactivated. Historical bookings and data are retained." : "Facility reactivated.");
            return renderModule(currentModule);
        }
        if (action === "entry") return openEntryForm();
        if (action === "checkin") return openEntryForm();
        if (action === "vehicle-exit") {
            const session = (await api("/api/operations")).find((item) => item.id === id);
            if (!session) throw new Error("The active parking session no longer exists.");
            const completed = await api("/api/operations/exit", { method: "POST", body: { sessionId: id } });
            notify(`Vehicle ${session.plate} exited. Parking charge: ${CURRENCY.format(completed.fee)}.`);
            return renderModule(currentModule);
        }
        if (action === "new-booking") return openBookingForm();
        if (action === "booking-checkin") return openEntryForm(id);
        if (action === "booking-cancel") {
            if (!window.confirm("Cancel this reservation and release its reserved space?")) return;
            const result = await api(`/api/bookings/${encodeURIComponent(id)}/cancel`, { method: "POST", body: { reason: "Cancelled by parking administrator" } });
            notify(`Reservation ${result.id} cancelled; its reserved capacity is available again.`);
            await refreshNotifications();
            return renderModule(currentModule);
        }
        if (action === "show-slots") {
            const facility = currentMap?._parkingFacilities?.find((item) => item.id === id) || await api(`/api/facilities/${encodeURIComponent(id)}`);
            if (currentMap) {
                currentMap.setView([facility.latitude, facility.longitude], 16);
                return selectFacility(id, type);
            }
            renderParkingLayout(facility, type);
            return;
        }
        if (action === "open-facility" || action === "map-facility") {
            location.hash = "map";
            await renderModule("map");
            if (action === "map-facility" && window.L) {
                const facility = currentMap?._parkingFacilities.find((item) => item.id === id);
                if (facility) {
                    currentMap.setView([facility.latitude, facility.longitude], 16);
                    selectFacility(id, document.getElementById("map-vehicle").value);
                }
            }
            return;
        }
        if (action === "map-book") return openBookingForm(id, type);
        if (action === "new-message") return openMessageForm();
        if (action === "read-notification") {
            await api(`/api/notifications/${encodeURIComponent(id)}/read`, { method: "PATCH", body: {} });
            await refreshNotifications();
            return renderModule(currentModule);
        }
        if (action === "new-support") return openSupportForm();
        if (action === "update-support") {
            const status = document.getElementById(`support-status-${id}`).value;
            const assignedTo = document.getElementById(`assignee-${id}`).value.trim();
            const rating = Number(document.getElementById(`support-rating-${id}`).value) || undefined;
            await api(`/api/support/${encodeURIComponent(id)}`, { method: "PATCH", body: { status, assignedTo, rating } });
            notify("Customer support case updated.");
            return renderModule(currentModule);
        }
        if (action === "rate-support") {
            const fields = [{ name: "rating", label: "Your rating", type: "select", required: true, options: [1, 2, 3, 4, 5].map((rating) => ({ value: rating, label: `${rating} star${rating === 1 ? "" : "s"}` })) }];
            return showForm("Rate your resolved support request", fields, async () => {
                const rating = Number(readFormFields(fields).rating);
                await api(`/api/support/${encodeURIComponent(id)}/rating`, { method: "PATCH", body: { rating } });
                notify("Thank you for your feedback.");
                await renderModule(currentModule);
            }, "Submit rating");
        }
        if (action === "edit-availability") return openAvailabilityForm(id);
        if (action === "export-data") return downloadReport("facilities");
        if (action === "export-payments") return downloadReport("transactions");
        if (action === "payment-paid" || action === "payment-refund") {
            const status = action === "payment-paid" ? "completed" : "refunded";
            if (status === "refunded" && !window.confirm("Mark this payment as refunded?")) return;
            await api("/api/transactions", { method: "POST", body: { id, status } });
            notify(`Payment marked ${status}.`);
            return renderModule(currentModule);
        }
        if (action === "edit-tariff") return openTariffForm(id);
        if (action === "new-user") return openUserForm();
        if (action === "issue-reset") {
            const user = (await api("/api/users")).find((item) => item.email.toLowerCase() === id.toLowerCase());
            if (!user) throw new Error("No registered SmartPark account uses this email address.");
            return displayResetCode(await api(`/api/users/${encodeURIComponent(user.id)}/password-reset`, { method: "POST", body: {} }), "Password reset code");
        }
        if (action === "toggle-user") {
            const users = await api("/api/users");
            const user = users.find((item) => item.id === id);
            await api(`/api/users/${encodeURIComponent(id)}`, { method: "PATCH", body: { status: user.status === "active" ? "inactive" : "active", role: user.role, facilityId: user.facility_id } });
            notify(`Account ${user.status === "active" ? "deactivated" : "reactivated"}.`);
            return renderModule(currentModule);
        }
        if (action === "edit-user-role") return editUserRole(id);
        if (action === "save-setting") {
            const input = button.closest(".setting-row").querySelector("input");
            await api(`/api/settings/${encodeURIComponent(id)}`, { method: "PATCH", body: { value: input.value.trim() } });
            notify("System setting saved.");
            return renderModule(currentModule);
        }
    };
    run().catch((error) => {
        const errorField = document.getElementById("form-error");
        if (formDialog.open && modalSubmit) {
            errorField.textContent = error.message;
            errorField.hidden = false;
        } else notify(error.message, true);
    });
}

function openMessageForm() {
    api("/api/facilities").then((facilities) => {
        const fields = [
            { name: "title", label: "Announcement title", required: true },
            { name: "recipient", label: "Recipient", type: "select", options: [{ value: "All operators", label: "All operators" }, ...facilities.map((facility) => ({ value: facility.name, label: facility.name }))] },
            { name: "facilityId", label: "Related facility", type: "select", options: [{ value: "", label: "No specific facility" }, ...facilities.map((facility) => ({ value: facility.id, label: facility.name }))] },
            { name: "message", label: "Message", type: "textarea", required: true, wide: true }
        ];
        showForm("Send an in-app announcement", fields, async () => {
            const message = readFormFields(fields);
            const result = await api("/api/notifications", { method: "POST", body: message });
            notify("The website announcement has been sent.");
            await refreshNotifications();
            return result && renderModule(currentModule);
        }, "Send message");
    }).catch((error) => notify(error.message, true));
}

async function openAvailabilityForm(facilityId) {
    const facility = await api(`/api/facilities/${encodeURIComponent(facilityId)}`);
    const inventory = facility.vehicles.filter((vehicle) => vehicle.capacity);
    const fields = [
        ...inventory.map((vehicle) => ({ name: `occupied-${vehicle.vehicleType}`, label: `${VEHICLE_NAMES[vehicle.vehicleType]} physically occupied`, type: "number", min: "0", max: String(vehicle.capacity - vehicle.reservedSpaces), value: vehicle.occupiedSpaces, help: `${vehicle.capacity} capacity · ${vehicle.reservedSpaces} spaces reserved` })),
        { name: "source", label: "Availability update source", value: facility.availabilitySource || "Operator report", wide: true }
    ];
    showForm(`Update ${facility.name} availability`, fields, async () => {
        const data = readFormFields(fields);
        const occupancy = Object.fromEntries(inventory.map((vehicle) => [vehicle.vehicleType, data[`occupied-${vehicle.vehicleType}`]]));
        await api(`/api/facilities/${encodeURIComponent(facility.id)}/availability`, { method: "PATCH", body: { occupancy, source: data.source } });
        notify("Physical occupancy, availability and source timestamp have been updated.");
        return renderModule(currentModule);
    }, "Save availability");
}

async function openTariffForm(facilityId) {
    const facility = await api(`/api/facilities/${encodeURIComponent(facilityId)}`);
    const inventory = facility.vehicles.filter((vehicle) => vehicle.capacity > 0);
    const fields = inventory.flatMap((vehicle) => [
        { name: `hourly-${vehicle.vehicleType}`, label: `${VEHICLE_NAMES[vehicle.vehicleType]} hourly fee (₹)`, type: "number", min: "0", step: "0.01", required: true, value: vehicle.hourlyRate },
        { name: `daily-${vehicle.vehicleType}`, label: `${VEHICLE_NAMES[vehicle.vehicleType]} daily fee (₹)`, type: "number", min: "0", step: "0.01", required: true, value: vehicle.dailyRate }
    ]);
    showForm(`Parking tariffs · ${facility.name}`, fields, async () => {
        const values = readFormFields(fields);
        const tariffs = Object.fromEntries(inventory.map((vehicle) => [vehicle.vehicleType, { hourlyRate: values[`hourly-${vehicle.vehicleType}`], dailyRate: values[`daily-${vehicle.vehicleType}`] }]));
        await api(`/api/facilities/${encodeURIComponent(facility.id)}`, { method: "PATCH", body: { tariffs } });
        notify("Vehicle-specific tariffs updated. New reservations and vehicle exits use these prices.");
        return renderModule(currentModule);
    }, "Save tariffs");
}

function openUserForm() {
    api("/api/facilities").then((facilities) => {
        const fields = [
            { name: "name", label: "Team member name", required: true },
            { name: "email", label: "Email address", type: "email", required: true },
            { name: "role", label: "Access role", type: "select", required: true, options: ["administrator", "parking operator", "customer"].map((role) => ({ value: role, label: role })) },
            { name: "facilityId", label: "Assigned facility", type: "select", options: [{ value: "", label: "All facilities" }, ...facilities.map((facility) => ({ value: facility.id, label: facility.name }))] }
        ];
        showForm("Register team member", fields, async () => {
            const newUser = await api("/api/users", { method: "POST", body: readFormFields(fields) });
            const invitation = await api(`/api/users/${encodeURIComponent(newUser.id)}/password-reset`, { method: "POST", body: {} });
            await renderModule(currentModule);
            return invitation;
        }, "Create account record");
    }).catch((error) => notify(error.message, true));
}

async function editUserRole(userId) {
    const [users, facilities] = await Promise.all([api("/api/users"), api("/api/facilities")]);
    const user = users.find((item) => item.id === userId);
    if (!user) throw new Error("Team member not found.");
    const fields = [
        { name: "role", label: "Access role", type: "select", value: user.role, options: ["administrator", "parking operator", "customer"].map((role) => ({ value: role, label: role })) },
        { name: "facilityId", label: "Assigned facility", type: "select", value: user.facility_id || "", options: [{ value: "", label: "All facilities" }, ...facilities.map((facility) => ({ value: facility.id, label: facility.name }))] }
    ];
    showForm(`Update access · ${user.name}`, fields, async () => {
        await api(`/api/users/${encodeURIComponent(userId)}`, { method: "PATCH", body: { ...readFormFields(fields), status: user.status } });
        notify("Team member access assignment updated.");
        return renderModule(currentModule);
    }, "Update access");
}

async function downloadReport(type) {
    const response = await fetch("/api/export", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type }) });
    if (!response.ok) throw new Error("Could not export this report.");
    const file = new Blob([await response.text()], { type: "text/csv;charset=utf-8" });
    const href = URL.createObjectURL(file);
    const anchor = document.createElement("a");
    anchor.href = href;
    anchor.download = type === "transactions" ? "smartpark-transactions.csv" : "smartpark-data.csv";
    anchor.click();
    URL.revokeObjectURL(href);
    notify(`${type === "transactions" ? "Payment report" : "Parking data"} downloaded.`);
}

function setAuthMode(mode, message = "") {
    authMode = mode;
    const setup = mode === "setup";
    const requestReset = mode === "request-reset";
    const resetting = mode === "complete-reset";
    document.getElementById("auth-title").textContent = setup ? "Create your administrator account" : requestReset ? "Request a password reset" : resetting ? "Set a new password" : "Welcome to SmartPark";
    document.getElementById("auth-description").textContent = setup
        ? "Create the first administrator account to set up your SmartPark workspace."
        : requestReset
            ? "Enter your account email. If an account exists, its administrator will be notified."
            : resetting
                ? "Ask your administrator for a single-use, 30-minute recovery code."
                : "Sign in to continue to your parking operations workspace.";
    document.getElementById("auth-name-row").hidden = !setup;
    document.getElementById("auth-code-row").hidden = !resetting;
    document.getElementById("auth-password-row").hidden = requestReset;
    document.getElementById("auth-confirm-row").hidden = !(setup || resetting);
    document.getElementById("auth-password-hint").hidden = !(setup || resetting);
    const nameInput = document.querySelector('#auth-name-row input');
    const resetInput = document.querySelector('#auth-code-row input');
    const passwordInput = document.querySelector('#auth-password-row input');
    const confirmInput = document.querySelector('#auth-confirm-row input');
    nameInput.required = setup;
    resetInput.required = resetting;
    passwordInput.required = !requestReset;
    confirmInput.required = setup || resetting;
    passwordInput.autocomplete = setup || resetting ? "new-password" : "current-password";
    document.getElementById("auth-submit").textContent = setup ? "Create administrator account" : requestReset ? "Request reset" : resetting ? "Set new password" : "Sign in";
    const secondary = document.getElementById("auth-secondary");
    secondary.hidden = setup;
    secondary.textContent = requestReset || resetting ? "Back to sign in" : "Forgot your password?";
    document.getElementById("auth-error").textContent = message;
    document.getElementById("auth-error").hidden = !message;
}

function configureAccount(user) {
    currentUser = user;
    const initials = user.name.trim().split(/\s+/).map((part) => part[0]).join("").slice(0, 2).toUpperCase();
    document.getElementById("sidebar-avatar").textContent = initials;
    document.getElementById("account-avatar").textContent = initials;
    document.getElementById("sidebar-account-name").textContent = user.name;
    document.getElementById("sidebar-account-role").innerHTML = `<i class="online-dot"></i>${escapeHtml(user.role)}`;
    const access = {
        administrator: Object.keys(MODULE_NAMES),
        "parking operator": ["home", "map", "operations", "business-processing", "parking-data", "message-center", "customer-service"],
        customer: ["home", "map", "business-processing", "message-center", "customer-service"]
    }[user.role] || [];
    document.querySelectorAll(".nav-link[data-module]").forEach((link) => { link.hidden = !access.includes(link.dataset.module); });
    document.getElementById("auth-screen").hidden = true;
}

async function initializeApplication() {
    const screen = document.getElementById("auth-screen");
    screen.hidden = false;
    try {
        const session = await api("/api/auth/session");
        if (session.authenticated) {
            configureAccount(session.user);
            const initialModule = location.hash.slice(1).split("?")[0];
            const visibleModule = [...document.querySelectorAll(".nav-link[data-module]:not([hidden])")].some((link) => link.dataset.module === initialModule);
            await renderModule(visibleModule ? initialModule : "home");
            await refreshNotifications();
        } else {
            setAuthMode(session.setupRequired ? "setup" : "login");
        }
    } catch (error) {
        setAuthMode("login", `${error.message} Check that the SmartPark server is running.`);
    }
}

async function displayResetCode(reset, heading) {
    await new Promise((resolve) => {
        showForm(heading, [
            { name: "email", label: "Account email", type: "email", value: reset.email, readonly: true },
            { name: "resetCode", label: "One-time password reset code", value: reset.resetCode, readonly: true, wide: true, help: `Expires ${formatDate(reset.expiresAt)}. Share securely with the account holder; this code cannot be viewed again.` }
        ], async () => resolve(), "Done");
        const originalSubmit = modalSubmit;
        modalSubmit = async () => { await originalSubmit(); resolve(); };
        formDialog.addEventListener("close", resolve, { once: true });
    });
}

async function signOut() {
    try { await api("/api/auth/logout", { method: "POST", body: {} }); }
    catch (error) { notify(error.message, true); }
    currentUser = null;
    document.getElementById("auth-screen").hidden = false;
    setAuthMode("login");
}

function openPasswordChangeForm() {
    const fields = [
        { name: "currentPassword", label: "Current password", type: "password", required: true, wide: true },
        { name: "password", label: "New password", type: "password", required: true, wide: true, help: "At least 6 characters." },
        { name: "confirmPassword", label: "Confirm new password", type: "password", required: true, wide: true }
    ];
    showForm("Change your password", fields, async () => {
        const values = readFormFields(fields);
        if (values.password !== values.confirmPassword) throw new Error("New passwords do not match.");
        await api("/api/auth/change-password", { method: "POST", body: values });
        formDialog.close();
        currentUser = null;
        document.getElementById("auth-screen").hidden = false;
        setAuthMode("login", "Password changed. Sign in again with your new password.");
    }, "Change password");
}

document.getElementById("auth-secondary").addEventListener("click", () => {
    setAuthMode(authMode === "login" ? "request-reset" : "login");
});

document.getElementById("auth-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const authForm = event.currentTarget;
    const values = Object.fromEntries(new FormData(authForm).entries());
    const errorElement = document.getElementById("auth-error");
    const submitButton = document.getElementById("auth-submit");
    errorElement.hidden = true;
    submitButton.disabled = true;
    try {
        if ((authMode === "setup" || authMode === "complete-reset") && values.password !== values.confirmPassword) {
            throw new Error("Passwords do not match.");
        }
        if (authMode === "request-reset") {
            const result = await api("/api/auth/password-reset-request", { method: "POST", body: { email: values.email } });
            authForm.elements.email.value = values.email;
            setAuthMode("complete-reset", result.message);
            return;
        }
        if (authMode === "complete-reset") {
            await api("/api/auth/password-reset-complete", { method: "POST", body: { email: values.email, resetCode: values.resetCode, password: values.password } });
            authForm.reset();
            setAuthMode("login", "Password reset successfully. Sign in with your new password.");
            return;
        }
        const endpoint = authMode === "setup" ? "/api/auth/setup" : "/api/auth/login";
        const session = await api(endpoint, { method: "POST", body: values });
        configureAccount(session.user);
        await renderModule(location.hash.slice(1).split("?")[0] || "home");
        await refreshNotifications();
    } catch (error) {
        errorElement.textContent = error.message;
        errorElement.hidden = false;
    } finally {
        submitButton.disabled = false;
    }
});

document.getElementById("logout-button").addEventListener("click", signOut);
document.getElementById("account-button").addEventListener("click", openPasswordChangeForm);

async function refreshNotifications() {
    const messages = await api("/api/notifications");
    const unread = messages.filter((message) => message.status === "unread").length;
    notificationCount.textContent = unread ? String(unread) : "";
    notificationCount.hidden = unread === 0;
    notificationPip.hidden = unread === 0;
}

document.querySelectorAll(".nav-link[data-module]").forEach((link) => {
    link.addEventListener("click", (event) => {
        event.preventDefault();
        location.hash = link.dataset.module;
        document.getElementById("sidebar").classList.remove("sidebar-open");
    });
});

window.addEventListener("hashchange", () => renderModule(location.hash.slice(1).split("?")[0] || "home"));
document.getElementById("mobile-menu").addEventListener("click", () => document.getElementById("sidebar").classList.toggle("sidebar-open"));
document.getElementById("notifications-shortcut").addEventListener("click", () => { location.hash = "message-center"; });

document.getElementById("modal-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!modalSubmit) return;
    const submitButton = document.getElementById("modal-submit");
    submitButton.disabled = true;
    document.getElementById("form-error").hidden = true;
    try {
        const followUp = await modalSubmit();
        formDialog.close();
        if (followUp?.resetCode) await displayResetCode(followUp, "Temporary access code");
    } catch (error) {
        const errorElement = document.getElementById("form-error");
        errorElement.textContent = error.message;
        errorElement.hidden = false;
    } finally { submitButton.disabled = false; }
});

document.querySelectorAll(".modal-close").forEach((button) => button.addEventListener("click", () => formDialog.close()));
content.addEventListener("click", handleAction);
content.addEventListener("click", (event) => {
    const link = event.target.closest("[data-module-link]");
    if (link) {
        location.hash = link.dataset.moduleLink;
    }
});

content.addEventListener("change", (event) => {
    if (event.target.matches("#statistics-period")) {
        location.hash = `statistics?period=${encodeURIComponent(event.target.value)}`;
        renderStatisticsPeriod(event.target.value);
    }
    if (event.target.matches("#include-inactive")) filterParkingRecords().catch((error) => notify(error.message, true));
});

content.addEventListener("input", (event) => {
    if (event.target.matches("#parking-search")) filterParkingRecords();
});

async function renderStatisticsPeriod(period) {
    try { renderStatistics(await api(`/api/stats?period=${encodeURIComponent(period)}`)); }
    catch (error) { notify(error.message, true); }
}

async function filterParkingRecords() {
    const search = document.getElementById("parking-search")?.value.trim() || "";
    const includeInactive = document.getElementById("include-inactive")?.checked;
    const rows = await api(`/api/parking-data?q=${encodeURIComponent(search)}&includeInactive=${Boolean(includeInactive)}`);
    const facilities = rows;
    const body = content.querySelector(".table-wrap tbody");
    if (!body) return;
    if (!body) return;
    body.innerHTML = facilities.flatMap((facility) => facility.vehicles.map((vehicle) => `<tr><td><strong>${escapeHtml(facility.name)}</strong><span class="table-sub">${escapeHtml(facility.address)}</span></td><td><span class="type-chip">${escapeHtml(VEHICLE_NAMES[vehicle.vehicleType])}</span></td><td>${COUNT.format(vehicle.capacity)}</td><td>${COUNT.format(vehicle.occupiedSpaces)}</td><td>${COUNT.format(vehicle.reservedSpaces)}</td><td><strong>${COUNT.format(vehicle.availableSpaces)}</strong></td><td>${escapeHtml(facility.availabilitySource)}<span class="table-sub">${formatDate(facility.availabilityUpdatedAt)}</span></td><td>${actionButton("Update count", "edit-availability", facility.id, "button-outline", `data-type="${escapeHtml(vehicle.vehicleType)}"`)}</td></tr>`)).join("");
}

document.getElementById("footer-year").textContent = new Date().getFullYear();
if (!location.hash) history.replaceState(null, "", "#home");
initializeApplication().catch((error) => {
    document.getElementById("auth-screen").hidden = false;
    setAuthMode("login", error.message);
});
