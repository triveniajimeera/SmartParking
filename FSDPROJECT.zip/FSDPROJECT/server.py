"""SmartPark's dependency-free Python and SQLite application server."""

from __future__ import annotations

import csv
import hashlib
import hmac
import io
import json
import math
import os
import re
import secrets
import sqlite3
import sys
import threading
import time
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from http import HTTPStatus
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit
import uuid


ROOT = Path(__file__).resolve().parent
DATABASE_PATH = Path(os.environ.get("SMARTPARK_DB_PATH", ROOT / "data" / "smartpark.sqlite")).resolve()
HOST = os.environ.get("HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT", "3000"))
VEHICLE_TYPES = ("bike", "car", "auto", "bicycle", "bus", "truck")
STATIC_FILES = {"parking.html", "style.css", "script.js"}
LOGIN_ATTEMPTS: dict[str, list[float]] = {}
RESET_ATTEMPTS: dict[str, list[float]] = {}
RATE_LIMIT_LOCK = threading.Lock()


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"


@contextmanager
def connect():
    DATABASE_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DATABASE_PATH, timeout=15)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA busy_timeout = 15000")
    try:
        with connection:
            yield connection
    finally:
        connection.close()


SCHEMA = """
CREATE TABLE IF NOT EXISTS facilities (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, address TEXT NOT NULL,
    city TEXT NOT NULL DEFAULT '', area TEXT NOT NULL, landmark TEXT NOT NULL DEFAULT '',
    latitude REAL NOT NULL, longitude REAL NOT NULL, zone TEXT NOT NULL,
    hourly_rate REAL NOT NULL DEFAULT 0, daily_rate REAL NOT NULL DEFAULT 0,
    opens_at TEXT NOT NULL DEFAULT '00:00', closes_at TEXT NOT NULL DEFAULT '23:59',
    supported_vehicles TEXT NOT NULL DEFAULT '[]', operating_hours TEXT NOT NULL DEFAULT '{}',
    holiday_schedule TEXT NOT NULL DEFAULT '[]', restrictions TEXT NOT NULL DEFAULT '',
    grace_period_minutes INTEGER NOT NULL DEFAULT 15, cancellation_hours INTEGER NOT NULL DEFAULT 2,
    active INTEGER NOT NULL DEFAULT 1, temporarily_closed INTEGER NOT NULL DEFAULT 0,
    closure_reason TEXT NOT NULL DEFAULT '', availability_source TEXT NOT NULL DEFAULT 'Operator report',
    availability_updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS facility_inventory (
    facility_id TEXT NOT NULL REFERENCES facilities(id) ON DELETE CASCADE,
    vehicle_type TEXT NOT NULL, capacity INTEGER NOT NULL CHECK(capacity >= 0),
    occupied_spaces INTEGER NOT NULL DEFAULT 0 CHECK(occupied_spaces >= 0),
    PRIMARY KEY(facility_id, vehicle_type), CHECK(occupied_spaces <= capacity)
);
CREATE TABLE IF NOT EXISTS vehicle_tariffs (
    facility_id TEXT NOT NULL, vehicle_type TEXT NOT NULL,
    hourly_rate REAL NOT NULL DEFAULT 0 CHECK(hourly_rate >= 0),
    daily_rate REAL NOT NULL DEFAULT 0 CHECK(daily_rate >= 0),
    PRIMARY KEY(facility_id, vehicle_type),
    FOREIGN KEY(facility_id, vehicle_type) REFERENCES facility_inventory(facility_id, vehicle_type) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS vehicles (
    id TEXT PRIMARY KEY, plate TEXT NOT NULL UNIQUE COLLATE NOCASE,
    vehicle_type TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bookings (
    id TEXT PRIMARY KEY, facility_id TEXT NOT NULL REFERENCES facilities(id),
    vehicle_id TEXT REFERENCES vehicles(id), vehicle_plate TEXT NOT NULL DEFAULT '',
    vehicle_type TEXT NOT NULL, customer_name TEXT NOT NULL, customer_email TEXT NOT NULL DEFAULT '',
    starts_at TEXT NOT NULL, ends_at TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'confirmed' CHECK(status IN ('pending','confirmed','checked_in','completed','cancelled','expired')),
    fee REAL NOT NULL, created_at TEXT NOT NULL, checked_in_at TEXT, completed_at TEXT,
    cancelled_at TEXT, cancellation_reason TEXT
);
CREATE INDEX IF NOT EXISTS bookings_facility_status ON bookings(facility_id, status);
CREATE INDEX IF NOT EXISTS bookings_created ON bookings(created_at);
CREATE TABLE IF NOT EXISTS parking_sessions (
    id TEXT PRIMARY KEY, facility_id TEXT NOT NULL REFERENCES facilities(id),
    vehicle_id TEXT NOT NULL REFERENCES vehicles(id), vehicle_type TEXT NOT NULL,
    space_number TEXT NOT NULL, booking_id TEXT REFERENCES bookings(id), entered_at TEXT NOT NULL,
    expected_exit_at TEXT, exited_at TEXT, fee REAL NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'parked' CHECK(status IN ('parked','completed')),
    UNIQUE(facility_id, space_number, exited_at)
);
CREATE INDEX IF NOT EXISTS parking_sessions_active ON parking_sessions(facility_id, status);
CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY, booking_id TEXT REFERENCES bookings(id), session_id TEXT REFERENCES parking_sessions(id),
    facility_id TEXT NOT NULL REFERENCES facilities(id), customer_name TEXT NOT NULL, amount REAL NOT NULL,
    payment_method TEXT NOT NULL DEFAULT 'Cash',
    status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('completed','pending','failed','refunded')),
    description TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, settled_at TEXT
);
CREATE TABLE IF NOT EXISTS support_requests (
    id TEXT PRIMARY KEY, customer_name TEXT NOT NULL, customer_email TEXT NOT NULL DEFAULT '',
    category TEXT NOT NULL, subject TEXT NOT NULL, message TEXT NOT NULL,
    facility_id TEXT REFERENCES facilities(id),
    status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','in_progress','resolved','rejected')),
    assigned_to TEXT NOT NULL DEFAULT 'Unassigned', rating INTEGER,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY, title TEXT NOT NULL, message TEXT NOT NULL,
    channel TEXT NOT NULL DEFAULT 'website', status TEXT NOT NULL DEFAULT 'unread',
    recipient TEXT NOT NULL DEFAULT 'All operators', facility_id TEXT REFERENCES facilities(id),
    booking_id TEXT REFERENCES bookings(id), created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL, details TEXT NOT NULL, actor TEXT NOT NULL DEFAULT 'Admin User',
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE,
    role TEXT NOT NULL CHECK(role IN ('administrator','parking operator','customer')),
    status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive')),
    facility_id TEXT REFERENCES facilities(id), password_hash TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS auth_sessions (
    token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL, expires_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS password_reset_tokens (
    token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at TEXT NOT NULL, used_at TEXT
);
CREATE TABLE IF NOT EXISTS password_reset_requests (
    id TEXT PRIMARY KEY, email TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','reviewed')),
    created_at TEXT NOT NULL, reviewed_at TEXT
);
CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL);
"""


def log_action(db: sqlite3.Connection, action: str, entity_type: str, entity_id: str, details: object) -> None:
    db.execute(
        "INSERT INTO audit_logs(action,entity_type,entity_id,details,created_at) VALUES(?,?,?,?,?)",
        (action, entity_type, entity_id, json.dumps(details, separators=(",", ":")), now()),
    )


def add_missing_column(db: sqlite3.Connection, table: str, name: str, definition: str) -> None:
    columns = {row["name"] for row in db.execute(f"PRAGMA table_info({table})")}
    if name not in columns:
        db.execute(f"ALTER TABLE {table} ADD COLUMN {name} {definition}")


def initialize_database() -> None:
    with connect() as db:
        db.executescript(SCHEMA)
        db.execute("PRAGMA journal_mode=WAL")
        add_missing_column(db, "facilities", "holiday_schedule", "TEXT NOT NULL DEFAULT '[]'")
        add_missing_column(db, "bookings", "vehicle_plate", "TEXT NOT NULL DEFAULT ''")
        add_missing_column(db, "users", "password_hash", "TEXT NOT NULL DEFAULT ''")
        for key, value in {
            "appName": "SmartPark", "currency": "INR", "availabilityAlertThreshold": "10",
            "availabilityStaleMinutes": "30", "backupEnabled": "true",
        }.items():
            db.execute("INSERT OR IGNORE INTO app_settings(key,value,updated_at) VALUES(?,?,?)", (key, value, now()))
        db.execute(
            """INSERT OR IGNORE INTO vehicle_tariffs(facility_id,vehicle_type,hourly_rate,daily_rate)
               SELECT i.facility_id,i.vehicle_type,f.hourly_rate,f.daily_rate
               FROM facility_inventory i JOIN facilities f ON f.id=i.facility_id"""
        )


def refresh_supported_vehicles(db: sqlite3.Connection, facility_id: str) -> None:
    types = [row["vehicle_type"] for row in db.execute(
        "SELECT vehicle_type FROM facility_inventory WHERE facility_id=? AND capacity>0 ORDER BY vehicle_type",
        (facility_id,),
    )]
    db.execute("UPDATE facilities SET supported_vehicles=? WHERE id=?", (json.dumps(types), facility_id))


def password_hash(password: object) -> str:
    validate_password(password)
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1, dklen=64, maxmem=128 * 1024 * 1024)
    return f"{salt.hex()}:{digest.hex()}"


def verify_password(password: object, stored: str) -> bool:
    if not isinstance(password, str) or len(password) > 256 or ":" not in stored:
        return False
    try:
        salt_hex, expected_hex = stored.split(":", 1)
        expected = bytes.fromhex(expected_hex)
        actual = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt_hex), n=2**14, r=8, p=1,
                                 dklen=len(expected), maxmem=128 * 1024 * 1024)
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


def validate_password(value: object) -> None:
    if not isinstance(value, str) or len(value) < 6 or len(value) > 256:
        raise ApiError(400, "Passwords must contain between 6 and 256 characters.")


def require_text(value: object, label: str, limit: int = 200) -> str:
    if not isinstance(value, str) or not value.strip() or len(value.strip()) > limit:
        raise ApiError(400, f"{label} is required and must not exceed {limit} characters.")
    return value.strip()


def require_enum(value: object, label: str, choices: tuple | list) -> str:
    if value not in choices:
        raise ApiError(400, f"{label} must be one of: {', '.join(choices)}.")
    return value


def record_dict(row: sqlite3.Row | None) -> dict | None:
    return dict(row) if row is not None else None


def expire_bookings(db: sqlite3.Connection) -> None:
    timestamp = now()
    expired = db.execute(
        "SELECT id,facility_id,customer_name,customer_email FROM bookings WHERE status IN ('pending','confirmed') AND ends_at<=?",
        (timestamp,),
    ).fetchall()
    if not expired:
        return
    owns_transaction = not db.in_transaction
    if owns_transaction:
        db.execute("BEGIN IMMEDIATE")
    try:
        for booking in expired:
            db.execute("UPDATE bookings SET status='expired' WHERE id=? AND status IN ('pending','confirmed')", (booking["id"],))
            db.execute("UPDATE transactions SET status='failed',settled_at=? WHERE booking_id=? AND status='pending'",
                       (timestamp, booking["id"]))
            db.execute(
                """INSERT INTO notifications(id,title,message,channel,status,recipient,facility_id,booking_id,created_at)
                   VALUES(?,?,?,'website','unread',?,?,?,?)""",
                (new_id("notice"), "Reservation expired",
                 f"Your reservation {booking['id']} ended without a check-in and its space has been released.",
                 booking["customer_email"] or booking["customer_name"], booking["facility_id"], booking["id"], timestamp),
            )
        log_action(db, "expired", "bookings", "expired-reservations", {"count": len(expired)})
        if owns_transaction:
            db.commit()
    except Exception:
        if owns_transaction:
            db.rollback()
        raise


def enrich_facility(db: sqlite3.Connection, row: sqlite3.Row) -> dict:
    expire_bookings(db)
    facility = dict(row)
    inventory = db.execute(
        """SELECT i.vehicle_type AS vehicleType,i.capacity,i.occupied_spaces AS occupiedSpaces,
                  COALESCE(t.hourly_rate,f.hourly_rate) AS hourlyRate,
                  COALESCE(t.daily_rate,f.daily_rate) AS dailyRate
           FROM facility_inventory i JOIN facilities f ON f.id=i.facility_id
           LEFT JOIN vehicle_tariffs t ON t.facility_id=i.facility_id AND t.vehicle_type=i.vehicle_type
           WHERE i.facility_id=? ORDER BY i.vehicle_type""", (facility["id"],),
    ).fetchall()
    reservations = db.execute(
        """SELECT vehicle_type,COUNT(*) AS amount FROM bookings
           WHERE facility_id=? AND status IN ('pending','confirmed') AND ends_at>? GROUP BY vehicle_type""",
        (facility["id"], now()),
    ).fetchall()
    reserved = {item["vehicle_type"]: item["amount"] for item in reservations}
    closed = bool(facility["temporarily_closed"])
    vehicles = []
    for item in inventory:
        vehicle = dict(item)
        vehicle["reservedSpaces"] = reserved.get(vehicle["vehicleType"], 0)
        vehicle["availableSpaces"] = 0 if closed else max(
            0, vehicle["capacity"] - vehicle["occupiedSpaces"] - vehicle["reservedSpaces"])
        prefix = vehicle["vehicleType"][:3].upper() + "-"
        occupied_slots = {
            session["space_number"] for session in db.execute(
                """SELECT space_number FROM parking_sessions
                   WHERE facility_id=? AND vehicle_type=? AND status='parked'""",
                (facility["id"], vehicle["vehicleType"]),
            )
        }
        vehicle["slots"] = [
            {
                "number": f"{prefix}{number:03d}",
                "status": "occupied" if f"{prefix}{number:03d}" in occupied_slots else "available",
            }
            for number in range(1, vehicle["capacity"] + 1)
        ]
        vehicles.append(vehicle)
    total_capacity = sum(item["capacity"] for item in vehicles)
    total_occupied = sum(item["occupiedSpaces"] for item in vehicles)
    total_reserved = sum(item["reservedSpaces"] for item in vehicles)
    facility.update({
        "active": bool(facility["active"]), "temporarilyClosed": closed,
        "supportedVehicles": json.loads(facility["supported_vehicles"]),
        "operatingHours": json.loads(facility["operating_hours"]),
        "holidaySchedule": json.loads(facility["holiday_schedule"]),
        "availabilityUpdatedAt": facility["availability_updated_at"],
        "availabilitySource": facility["availability_source"],
        "hourlyRate": facility["hourly_rate"], "dailyRate": facility["daily_rate"],
        "vehicles": vehicles, "capacity": total_capacity, "occupiedSpaces": total_occupied,
        "reservedSpaces": total_reserved,
        "availableSpaces": 0 if closed else max(0, total_capacity - total_occupied - total_reserved),
    })
    return facility


def get_facility(db: sqlite3.Connection, facility_id: str) -> dict | None:
    row = db.execute("SELECT * FROM facilities WHERE id=?", (facility_id,)).fetchone()
    return enrich_facility(db, row) if row else None


def list_facilities(db: sqlite3.Connection, query: str = "", zone: str = "",
                    vehicle_type: str = "", include_inactive: bool = False) -> list[dict]:
    clauses, values = [], []
    if not include_inactive:
        clauses.append("f.active=1")
    if query:
        clauses.append("(f.name LIKE ? OR f.address LIKE ? OR f.city LIKE ? OR f.area LIKE ? OR f.landmark LIKE ?)")
        values.extend([f"%{query}%"] * 5)
    if zone:
        clauses.append("f.zone=?")
        values.append(zone)
    if vehicle_type:
        require_enum(vehicle_type, "Vehicle type", VEHICLE_TYPES)
        clauses.append("EXISTS(SELECT 1 FROM facility_inventory i WHERE i.facility_id=f.id AND i.vehicle_type=? AND i.capacity>0)")
        values.append(vehicle_type)
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    rows = db.execute(f"SELECT f.* FROM facilities f{where} ORDER BY f.name", values).fetchall()
    return [enrich_facility(db, row) for row in rows]


def get_stats(db: sqlite3.Connection) -> dict:
    expire_bookings(db)
    totals = db.execute(
        """SELECT COUNT(DISTINCT f.id) AS totalFacilities,COALESCE(SUM(i.capacity),0) AS totalSpaces,
                  COALESCE(SUM(i.occupied_spaces),0) AS occupiedSpaces
           FROM facilities f LEFT JOIN facility_inventory i ON i.facility_id=f.id WHERE f.active=1"""
    ).fetchone()
    reserved = db.execute(
        """SELECT COUNT(*) FROM bookings b JOIN facilities f ON f.id=b.facility_id
           WHERE f.active=1 AND b.status IN ('pending','confirmed') AND b.ends_at>?""", (now(),)
    ).fetchone()[0]
    active_bookings = db.execute(
        """SELECT COUNT(*) FROM bookings b JOIN facilities f ON f.id=b.facility_id
           WHERE f.active=1 AND b.status IN ('pending','confirmed','checked_in')"""
    ).fetchone()[0]
    cancelled = db.execute(
        "SELECT COUNT(*) FROM bookings b JOIN facilities f ON f.id=b.facility_id WHERE f.active=1 AND b.status='cancelled'"
    ).fetchone()[0]
    facilities = list_facilities(db)
    settings = {row["key"]: row["value"] for row in db.execute("SELECT key,value FROM app_settings")}
    threshold = float(settings.get("availabilityAlertThreshold", "10")) / 100
    stale_after = float(settings.get("availabilityStaleMinutes", "30"))
    alerts = []
    for facility in facilities:
        if not facility["temporarilyClosed"] and facility["capacity"] and facility["availableSpaces"] / facility["capacity"] <= threshold:
            alerts.append({
                "type": "full", "facilityId": facility["id"], "facility": facility["name"],
                "message": "Facility is full" if facility["availableSpaces"] == 0 else f"{facility['availableSpaces']} spaces remaining",
            })
        try:
            age = (datetime.now(timezone.utc) - datetime.fromisoformat(facility["availabilityUpdatedAt"].replace("Z", "+00:00"))).total_seconds() / 60
        except (ValueError, TypeError):
            age = stale_after + 1
        if age > stale_after:
            alerts.append({
                "type": "stale", "facilityId": facility["id"], "facility": facility["name"],
                "message": f"Availability not updated for {math.floor(age)} minutes",
            })
    return {
        **dict(totals), "reservedSpaces": reserved,
        "availableSpaces": max(0, totals["totalSpaces"] - totals["occupiedSpaces"] - reserved),
        "activeBookings": active_bookings, "cancelledBookings": cancelled,
        "occupancyRate": round((totals["occupiedSpaces"] + reserved) / totals["totalSpaces"] * 100) if totals["totalSpaces"] else 0,
        "activeVehicles": db.execute("SELECT COUNT(*) FROM parking_sessions WHERE status='parked'").fetchone()[0],
        "recentFacilities": [dict(row) for row in db.execute(
            """SELECT id,name,area,availability_updated_at AS updatedAt,availability_source AS source
               FROM facilities WHERE active=1 ORDER BY availability_updated_at DESC LIMIT 5""")],
        "alerts": alerts, "zones": sorted({facility["zone"] for facility in facilities}),
        "recentBookings": [dict(row) for row in db.execute(
            """SELECT b.*,f.name AS facility_name FROM bookings b JOIN facilities f ON f.id=b.facility_id
               ORDER BY b.created_at DESC LIMIT 8""")],
        "recentActivity": [dict(row) for row in db.execute("SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 10")],
    }


def count_reservations(db: sqlite3.Connection, facility_id: str, vehicle_type: str) -> int:
    expire_bookings(db)
    return db.execute(
        """SELECT COUNT(*) FROM bookings WHERE facility_id=? AND vehicle_type=?
           AND status IN ('pending','confirmed') AND ends_at>?""", (facility_id, vehicle_type, now())
    ).fetchone()[0]


def price_for(hours: float, hourly_rate: float, daily_rate: float) -> float:
    hourly = max(1, hours) * hourly_rate
    daily = math.ceil(max(1, hours) / 24) * daily_rate
    return round(min(hourly, daily if daily > 0 else float("inf")) + 1e-9, 2)


@contextmanager
def write_transaction(db: sqlite3.Connection):
    db.execute("BEGIN IMMEDIATE")
    try:
        yield
        db.commit()
    except Exception:
        db.rollback()
        raise


def save_booking(db: sqlite3.Connection, body: dict) -> dict:
    facility_id = require_text(body.get("facilityId"), "Facility")
    customer_name = require_text(body.get("customerName"), "Customer name")
    vehicle_type = require_enum(body.get("vehicleType"), "Vehicle type", VEHICLE_TYPES)
    try:
        start = datetime.fromisoformat(body["startsAt"].replace("Z", "+00:00"))
        end = datetime.fromisoformat(body["endsAt"].replace("Z", "+00:00"))
    except (ValueError, TypeError, KeyError):
        raise ApiError(400, "A valid booking start and end time is required.") from None
    if start.tzinfo is None:
        start = start.replace(tzinfo=timezone.utc)
    if end.tzinfo is None:
        end = end.replace(tzinfo=timezone.utc)
    if start >= end:
        raise ApiError(400, "Provide a valid parking start and end time.")
    if start.timestamp() < time.time() - 60:
        raise ApiError(400, "Reservations must start in the future.")
    with write_transaction(db):
        facility = get_facility(db, facility_id)
        if not facility or not facility["active"] or facility["temporarilyClosed"]:
            raise ApiError(409, "This facility is unavailable for booking.")
        inventory = next((item for item in facility["vehicles"] if item["vehicleType"] == vehicle_type), None)
        if not inventory:
            raise ApiError(409, "This facility does not support the selected vehicle type.")
        if inventory["capacity"] - inventory["occupiedSpaces"] - count_reservations(db, facility_id, vehicle_type) <= 0:
            raise ApiError(409, "No unreserved spaces are available for this vehicle type.")
        duration = (end - start).total_seconds() / 3600
        fee = price_for(duration, inventory["hourlyRate"], inventory["dailyRate"])
        booking_id, timestamp = new_id("booking"), now()
        customer_email = str(body.get("customerEmail") or "").strip()
        db.execute(
            """INSERT INTO bookings(id,facility_id,vehicle_type,customer_name,customer_email,starts_at,ends_at,fee,created_at)
               VALUES(?,?,?,?,?,?,?,?,?)""",
            (booking_id, facility_id, vehicle_type, customer_name, customer_email,
             start.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
             end.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"), fee, timestamp),
        )
        db.execute(
            """INSERT INTO transactions(id,booking_id,facility_id,customer_name,amount,payment_method,status,description,created_at)
               VALUES(?,?,?,?,?,?,'pending',?,?)""",
            (new_id("payment"), booking_id, facility_id, customer_name, fee,
             body.get("paymentMethod") or "Cash", f"Parking reservation {booking_id}", timestamp),
        )
        db.execute(
            """INSERT INTO notifications(id,title,message,channel,status,recipient,facility_id,booking_id,created_at)
               VALUES(?,?,?,'website','unread',?,?,?,?)""",
            (new_id("notice"), "Booking confirmed", f"Your {vehicle_type} parking reservation at {facility['name']} is confirmed.",
             customer_email or customer_name, facility_id, booking_id, timestamp),
        )
        log_action(db, "created", "booking", booking_id, {"facility": facility["name"], "vehicleType": vehicle_type, "fee": fee})
    return dict(db.execute(
        "SELECT b.*,f.name AS facility_name FROM bookings b JOIN facilities f ON f.id=b.facility_id WHERE b.id=?",
        (booking_id,),
    ).fetchone())


def vehicle_entry(db: sqlite3.Connection, body: dict, booking_id: str | None = None) -> dict:
    facility_id = require_text(body.get("facilityId"), "Parking facility")
    plate = require_text(body.get("plate"), "Vehicle registration").upper()
    vehicle_type = require_enum(body.get("vehicleType"), "Vehicle type", VEHICLE_TYPES)
    with write_transaction(db):
        facility = get_facility(db, facility_id)
        if not facility or not facility["active"] or facility["temporarilyClosed"]:
            raise ApiError(409, "This facility is unavailable for vehicle entry.")
        inventory = next((item for item in facility["vehicles"] if item["vehicleType"] == vehicle_type), None)
        if not inventory:
            raise ApiError(409, "This facility does not support this vehicle type.")
        registered = db.execute("SELECT * FROM vehicles WHERE plate=? COLLATE NOCASE", (plate,)).fetchone()
        if registered and registered["vehicle_type"] != vehicle_type:
            raise ApiError(409, f"Vehicle {plate} is registered as {registered['vehicle_type']}.")
        booking = db.execute("SELECT * FROM bookings WHERE id=? AND facility_id=?", (booking_id, facility_id)).fetchone() if booking_id else None
        if booking_id and (not booking or booking["status"] != "confirmed" or booking["vehicle_type"] != vehicle_type):
            raise ApiError(409, "A matching confirmed booking is required to check in.")
        if booking:
            start = datetime.fromisoformat(booking["starts_at"].replace("Z", "+00:00"))
            end = datetime.fromisoformat(booking["ends_at"].replace("Z", "+00:00"))
            grace = facility["grace_period_minutes"]
            if datetime.now(timezone.utc) < start - timedelta(minutes=grace) or datetime.now(timezone.utc) > end:
                raise ApiError(409, "This reservation is outside its check-in window.")
        protected_reservations = inventory["reservedSpaces"] - (1 if booking else 0)
        if inventory["occupiedSpaces"] + protected_reservations >= inventory["capacity"]:
            raise ApiError(409, "This facility has no unallocated spaces for this vehicle type.")
        if registered and db.execute(
            "SELECT 1 FROM parking_sessions WHERE vehicle_id=? AND status='parked'", (registered["id"],)
        ).fetchone():
            raise ApiError(409, "This vehicle already has an active parking session.")
        vehicle_id = registered["id"] if registered else new_id("vehicle")
        if not registered:
            db.execute("INSERT INTO vehicles(id,plate,vehicle_type,created_at) VALUES(?,?,?,?)",
                       (vehicle_id, plate, vehicle_type, now()))
        active_spaces = {
            row["space_number"] for row in db.execute(
                "SELECT space_number FROM parking_sessions WHERE facility_id=? AND vehicle_type=? AND status='parked'",
                (facility_id, vehicle_type),
            )
        }
        prefix = vehicle_type[:3].upper() + "-"
        slot = next((number for number in range(1, inventory["capacity"] + 1)
                     if f"{prefix}{number:03d}" not in active_spaces), None)
        if slot is None:
            raise ApiError(409, f"No unallocated {vehicle_type} spaces are available.")
        entered_at, session_id = now(), new_id("session")
        db.execute("UPDATE facility_inventory SET occupied_spaces=occupied_spaces+1 WHERE facility_id=? AND vehicle_type=?",
                   (facility_id, vehicle_type))
        db.execute("UPDATE facilities SET availability_updated_at=? WHERE id=?", (entered_at, facility_id))
        db.execute(
            """INSERT INTO parking_sessions(id,facility_id,vehicle_id,vehicle_type,space_number,booking_id,entered_at,expected_exit_at)
               VALUES(?,?,?,?,?,?,?,?)""",
            (session_id, facility_id, vehicle_id, vehicle_type, f"{prefix}{slot:03d}", booking_id,
             entered_at, body.get("expectedExitAt") or None),
        )
        if booking:
            db.execute("UPDATE bookings SET status='checked_in',vehicle_id=?,vehicle_plate=?,checked_in_at=? WHERE id=?",
                       (vehicle_id, plate, entered_at, booking_id))
        log_action(db, "vehicle entry", "parking session", session_id,
                   {"plate": plate, "facility": facility["name"], "spaceNumber": f"{prefix}{slot:03d}"})
    return dict(db.execute(
        """SELECT ps.*,v.plate,f.name AS facility_name FROM parking_sessions ps
           JOIN vehicles v ON v.id=ps.vehicle_id JOIN facilities f ON f.id=ps.facility_id WHERE ps.id=?""",
        (session_id,),
    ).fetchone())


def vehicle_exit(db: sqlite3.Connection, body: dict) -> dict:
    if body.get("sessionId"):
        session_id = body["sessionId"]
    else:
        plate = require_text(body.get("plate"), "Vehicle registration").upper()
        active = db.execute(
            """SELECT ps.* FROM parking_sessions ps JOIN vehicles v ON v.id=ps.vehicle_id
               WHERE v.plate=? COLLATE NOCASE AND ps.status='parked'""", (plate,)
        ).fetchone()
        session_id = active["id"] if active else None
    if not session_id:
        raise ApiError(404, "No active parking session was found for this vehicle.")
    with write_transaction(db):
        session = db.execute("SELECT * FROM parking_sessions WHERE id=? AND status='parked'", (session_id,)).fetchone()
        if not session:
            raise ApiError(404, "No active parking session was found for this vehicle.")
        facility = get_facility(db, session["facility_id"])
        inventory = next(item for item in facility["vehicles"] if item["vehicleType"] == session["vehicle_type"])
        entered = datetime.fromisoformat(session["entered_at"].replace("Z", "+00:00"))
        hours = max(1, math.ceil((datetime.now(timezone.utc) - entered).total_seconds() / 3600))
        fee = price_for(hours, inventory["hourlyRate"], inventory["dailyRate"])
        timestamp = now()
        db.execute("UPDATE parking_sessions SET status='completed',exited_at=?,fee=? WHERE id=?",
                   (timestamp, fee, session["id"]))
        db.execute(
            "UPDATE facility_inventory SET occupied_spaces=occupied_spaces-1 WHERE facility_id=? AND vehicle_type=? AND occupied_spaces>0",
            (session["facility_id"], session["vehicle_type"]),
        )
        db.execute("UPDATE facilities SET availability_updated_at=? WHERE id=?", (timestamp, session["facility_id"]))
        if session["booking_id"]:
            db.execute("UPDATE bookings SET status='completed',completed_at=? WHERE id=?", (timestamp, session["booking_id"]))
        db.execute(
            """INSERT INTO transactions(id,session_id,facility_id,customer_name,amount,payment_method,status,description,created_at,settled_at)
               VALUES(?,?,?,'Walk-in customer',?,'Cash','completed',?,?,?)""",
            (new_id("payment"), session["id"], session["facility_id"], fee,
             f"Parking fee for {session['vehicle_type']} vehicle", timestamp, timestamp),
        )
        log_action(db, "vehicle exit", "parking session", session["id"], {"facility": facility["name"], "fee": fee})
    result = dict(session)
    result.update(status="completed", exited_at=timestamp, fee=fee, facility_name=facility["name"])
    result["plate"] = db.execute("SELECT plate FROM vehicles WHERE id=?", (session["vehicle_id"],)).fetchone()["plate"]
    return result


def validate_facility(body: dict, partial: bool = False) -> dict:
    value = dict(body)
    for key, label, limit in (("name", "Facility name", 200), ("address", "Address", 500),
                              ("area", "Area", 200), ("zone", "Zone", 200)):
        if not partial or key in body:
            value[key] = require_text(body.get(key), label, limit)
    for key, upper in (("latitude", 90), ("longitude", 180)):
        if partial and key not in body:
            continue
        coordinate = body.get(key)
        if isinstance(coordinate, bool) or not isinstance(coordinate, (int, float)) or not math.isfinite(coordinate) or abs(coordinate) > upper:
            raise ApiError(400, f"A valid facility {key} is required.")
    for key in ("hourlyRate", "dailyRate", "gracePeriodMinutes", "cancellationHours"):
        if key in body and (isinstance(body[key], bool) or not isinstance(body[key], (int, float)) or not math.isfinite(body[key]) or body[key] < 0):
            raise ApiError(400, f"{key} must be a nonnegative number.")
    capacities = body.get("capacities")
    if not partial and not isinstance(capacities, dict):
        raise ApiError(400, "Per-vehicle capacity is required.")
    if capacities is not None:
        for vehicle_type, capacity in capacities.items():
            require_enum(vehicle_type, "Vehicle type", VEHICLE_TYPES)
            if isinstance(capacity, bool) or not isinstance(capacity, int) or capacity < 0:
                raise ApiError(400, "Vehicle capacities must be nonnegative whole numbers.")
        if not any(capacity > 0 for capacity in capacities.values()):
            raise ApiError(400, "At least one vehicle type must have parking capacity.")
    tariffs = body.get("tariffs")
    if tariffs is not None:
        if not isinstance(tariffs, dict):
            raise ApiError(400, "Vehicle tariffs must be provided as an object.")
        for vehicle_type, tariff in tariffs.items():
            require_enum(vehicle_type, "Vehicle type", VEHICLE_TYPES)
            if (not isinstance(tariff, dict) or any(isinstance(tariff.get(key), bool) or
                    not isinstance(tariff.get(key), (int, float)) or not math.isfinite(tariff[key]) or tariff[key] < 0
                    for key in ("hourlyRate", "dailyRate"))):
                raise ApiError(400, "Vehicle parking tariffs must be nonnegative numbers.")
    for key, expected in (("operatingHours", dict), ("holidaySchedule", list)):
        if key in body and not isinstance(body[key], expected):
            raise ApiError(400, f"{key} must be a JSON {expected.__name__}.")
    for key in ("opensAt", "closesAt"):
        if key in body and (not isinstance(body[key], str) or not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", body[key])):
            raise ApiError(400, f"{key} must be a valid 24-hour time (HH:MM).")
    for key in ("active", "temporarilyClosed"):
        if key in body and not isinstance(body[key], bool):
            raise ApiError(400, f"{key} must be a boolean.")
    if "closureReason" in body and (not isinstance(body["closureReason"], str) or len(body["closureReason"]) > 1000):
        raise ApiError(400, "Closure reason must not exceed 1000 characters.")
    return value


def create_facility(db: sqlite3.Connection, body: dict) -> dict:
    if not any(capacity > 0 for capacity in body["capacities"].values()):
        raise ApiError(400, "A facility must offer at least one parking space.")
    facility_id, timestamp = new_id("facility"), now()
    with write_transaction(db):
        db.execute(
            """INSERT INTO facilities
               (id,name,address,city,area,landmark,latitude,longitude,zone,hourly_rate,daily_rate,opens_at,closes_at,
                supported_vehicles,operating_hours,holiday_schedule,restrictions,grace_period_minutes,cancellation_hours,availability_updated_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'[]',?,?,?,?,?,?)""",
            (facility_id, body["name"], body["address"], body.get("city") or "", body["area"],
             body.get("landmark") or "", body["latitude"], body["longitude"], body["zone"],
             body.get("hourlyRate", 0), body.get("dailyRate", 0), body.get("opensAt", "00:00"),
             body.get("closesAt", "23:59"), json.dumps(body.get("operatingHours", {})),
             json.dumps(body.get("holidaySchedule", [])), body.get("restrictions", ""),
             body.get("gracePeriodMinutes", 15), body.get("cancellationHours", 2), timestamp),
        )
        for vehicle_type, capacity in body["capacities"].items():
            if capacity <= 0:
                continue
            tariff = body.get("tariffs", {}).get(vehicle_type, {})
            db.execute(
                "INSERT INTO facility_inventory(facility_id,vehicle_type,capacity,occupied_spaces) VALUES(?,?,?,0)",
                (facility_id, vehicle_type, capacity),
            )
            db.execute(
                "INSERT INTO vehicle_tariffs(facility_id,vehicle_type,hourly_rate,daily_rate) VALUES(?,?,?,?)",
                (facility_id, vehicle_type, tariff.get("hourlyRate", body.get("hourlyRate", 0)),
                 tariff.get("dailyRate", body.get("dailyRate", 0))),
            )
        refresh_supported_vehicles(db, facility_id)
        log_action(db, "created", "facility", facility_id, body)
    return get_facility(db, facility_id)


def update_facility(db: sqlite3.Connection, facility_id: str, body: dict) -> dict | None:
    columns = {
        "name": "name", "address": "address", "city": "city", "area": "area", "landmark": "landmark",
        "latitude": "latitude", "longitude": "longitude", "zone": "zone", "hourlyRate": "hourly_rate",
        "dailyRate": "daily_rate", "opensAt": "opens_at", "closesAt": "closes_at",
        "restrictions": "restrictions", "gracePeriodMinutes": "grace_period_minutes",
        "cancellationHours": "cancellation_hours", "active": "active",
        "temporarilyClosed": "temporarily_closed", "closureReason": "closure_reason",
        "availabilitySource": "availability_source",
    }
    with write_transaction(db):
        existing = db.execute("SELECT * FROM facilities WHERE id=?", (facility_id,)).fetchone()
        if not existing:
            return None
        if body.get("active") is False and db.execute(
            "SELECT 1 FROM bookings WHERE facility_id=? AND status IN ('pending','confirmed','checked_in') LIMIT 1",
            (facility_id,),
        ).fetchone():
            raise ApiError(409, "Cancel open bookings and close active parking sessions before deactivating this facility.")
        assignments, values = [], []
        for key, column in columns.items():
            if key in body:
                assignments.append(f"{column}=?")
                values.append(int(body[key]) if isinstance(body[key], bool) else body[key])
        for key, column in (("operatingHours", "operating_hours"), ("holidaySchedule", "holiday_schedule")):
            if key in body:
                assignments.append(f"{column}=?")
                values.append(json.dumps(body[key]))
        if assignments:
            assignments.append("availability_updated_at=?")
            values.extend([now(), facility_id])
            db.execute(f"UPDATE facilities SET {','.join(assignments)} WHERE id=?", values)
        capacities = body.get("capacities")
        if capacities is not None:
            current = {row["vehicle_type"]: dict(row) for row in db.execute(
                "SELECT vehicle_type,capacity,occupied_spaces FROM facility_inventory WHERE facility_id=?", (facility_id,)
            )}
            for vehicle_type, prior in current.items():
                if vehicle_type not in capacities or capacities[vehicle_type] == 0:
                    if prior["occupied_spaces"] or count_reservations(db, facility_id, vehicle_type):
                        raise ApiError(409, f"The {vehicle_type} inventory has active vehicles or reservations and cannot be removed.")
                    db.execute("DELETE FROM facility_inventory WHERE facility_id=? AND vehicle_type=?", (facility_id, vehicle_type))
            for vehicle_type, capacity in capacities.items():
                if capacity == 0:
                    continue
                prior = current.get(vehicle_type)
                reserved = count_reservations(db, facility_id, vehicle_type)
                occupied = prior["occupied_spaces"] if prior else 0
                if capacity < occupied + reserved:
                    raise ApiError(409, f"Capacity for {vehicle_type} cannot be lower than its occupied and reserved spaces.")
                db.execute(
                    """INSERT INTO facility_inventory(facility_id,vehicle_type,capacity,occupied_spaces) VALUES(?,?,?,?)
                       ON CONFLICT(facility_id,vehicle_type) DO UPDATE SET capacity=excluded.capacity""",
                    (facility_id, vehicle_type, capacity, occupied),
                )
            refresh_supported_vehicles(db, facility_id)
        tariffs = body.get("tariffs")
        if tariffs:
            for vehicle_type, tariff in tariffs.items():
                if not db.execute(
                    "SELECT 1 FROM facility_inventory WHERE facility_id=? AND vehicle_type=?", (facility_id, vehicle_type)
                ).fetchone():
                    raise ApiError(400, f"Configure {vehicle_type} parking capacity before setting its tariff.")
                db.execute(
                    """INSERT INTO vehicle_tariffs(facility_id,vehicle_type,hourly_rate,daily_rate) VALUES(?,?,?,?)
                       ON CONFLICT(facility_id,vehicle_type) DO UPDATE SET hourly_rate=excluded.hourly_rate,daily_rate=excluded.daily_rate""",
                    (facility_id, vehicle_type, tariff["hourlyRate"], tariff["dailyRate"]),
                )
        log_action(db, "updated", "facility", facility_id, body)
    return get_facility(db, facility_id)


def setup_administrator(db: sqlite3.Connection, body: dict) -> dict:
    with write_transaction(db):
        if db.execute("SELECT 1 FROM users LIMIT 1").fetchone():
            raise ApiError(409, "The initial administrator account has already been configured.")
        name = require_text(body.get("name"), "Name")
        email = require_text(body.get("email"), "Email", 254).lower()
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
            raise ApiError(400, "Provide a valid email address for the administrator account.")
        user_id = new_id("user")
        db.execute(
            "INSERT INTO users(id,name,email,role,status,password_hash,created_at) VALUES(?,?,?,'administrator','active',?,?)",
            (user_id, name, email, password_hash(body.get("password")), now()),
        )
        log_action(db, "created initial administrator", "user", user_id, {"email": email})
    return record_dict(db.execute("SELECT id,name,email,role,status,facility_id FROM users WHERE id=?", (user_id,)).fetchone())


def authenticate(db: sqlite3.Connection, email: object, password: object) -> dict | None:
    row = db.execute("SELECT * FROM users WHERE email=? COLLATE NOCASE", (str(email or "").strip(),)).fetchone()
    if not row or row["status"] != "active" or not verify_password(password, row["password_hash"]):
        return None
    return {key: row[key] for key in ("id", "name", "email", "role", "status", "facility_id")}


def create_session(db: sqlite3.Connection, user_id: str) -> tuple[str, str]:
    token, created = secrets.token_hex(32), now()
    expires = (datetime.now(timezone.utc) + timedelta(hours=8)).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    digest = hashlib.sha256(token.encode()).hexdigest()
    db.execute("INSERT INTO auth_sessions(token_hash,user_id,created_at,expires_at) VALUES(?,?,?,?)",
               (digest, user_id, created, expires))
    return token, expires


def get_session(db: sqlite3.Connection, token: str | None) -> dict | None:
    if not token or not re.fullmatch(r"[a-f0-9]{64}", token):
        return None
    digest = hashlib.sha256(token.encode()).hexdigest()
    row = db.execute(
        """SELECT u.id,u.name,u.email,u.role,u.status,u.facility_id,s.expires_at FROM auth_sessions s
           JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.status='active'""",
        (digest, now()),
    ).fetchone()
    return record_dict(row)


def issue_password_reset(db: sqlite3.Connection, user_id: str) -> dict:
    with write_transaction(db):
        user = db.execute("SELECT id,email,status FROM users WHERE id=?", (user_id,)).fetchone()
        if not user:
            raise ApiError(404, "Account not found.")
        if user["status"] != "active":
            raise ApiError(409, "Reactivate this account before issuing a password reset.")
        reset_code = secrets.token_urlsafe(18)
        digest = hashlib.sha256(reset_code.encode()).hexdigest()
        expires = (datetime.now(timezone.utc) + timedelta(minutes=30)).isoformat(timespec="milliseconds").replace("+00:00", "Z")
        db.execute("DELETE FROM password_reset_tokens WHERE user_id=?", (user_id,))
        db.execute("INSERT INTO password_reset_tokens(token_hash,user_id,expires_at) VALUES(?,?,?)", (digest, user_id, expires))
        db.execute("UPDATE password_reset_requests SET status='reviewed',reviewed_at=? WHERE email=? COLLATE NOCASE AND status='pending'",
                   (now(), user["email"]))
        log_action(db, "issued password reset", "user", user_id, {"expiresAt": expires})
    return {"resetCode": reset_code, "email": user["email"], "expiresAt": expires}


def complete_password_reset(db: sqlite3.Connection, email: object, code: object, password: object) -> None:
    user = db.execute("SELECT id FROM users WHERE email=? COLLATE NOCASE AND status='active'", (str(email or "").strip(),)).fetchone()
    token_digest = hashlib.sha256(str(code or "").encode()).hexdigest()
    token = db.execute("SELECT * FROM password_reset_tokens WHERE token_hash=? AND expires_at>? AND used_at IS NULL",
                       (token_digest, now())).fetchone()
    if not user or not token or token["user_id"] != user["id"]:
        raise ApiError(400, "The account, reset code, or reset-code expiry is invalid.")
    digest = password_hash(password)
    with write_transaction(db):
        db.execute("UPDATE users SET password_hash=? WHERE id=?", (digest, user["id"]))
        db.execute("UPDATE password_reset_tokens SET used_at=? WHERE token_hash=?", (now(), token_digest))
        db.execute("DELETE FROM auth_sessions WHERE user_id=?", (user["id"],))
        log_action(db, "reset password", "user", user["id"], {})


def change_password(db: sqlite3.Connection, user_id: str, current: object, password: object) -> None:
    row = db.execute("SELECT password_hash FROM users WHERE id=?", (user_id,)).fetchone()
    if not row or not verify_password(current, row["password_hash"]):
        raise ApiError(400, "Current password is incorrect.")
    digest = password_hash(password)
    with write_transaction(db):
        db.execute("UPDATE users SET password_hash=? WHERE id=?", (digest, user_id))
        db.execute("DELETE FROM auth_sessions WHERE user_id=?", (user_id,))
        log_action(db, "changed password", "user", user_id, {})


def request_password_reset(db: sqlite3.Connection, email: object) -> None:
    normalized = str(email or "").strip().lower()
    if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", normalized):
        return
    timestamp = now()
    db.execute("INSERT INTO password_reset_requests(id,email,created_at) VALUES(?,?,?)",
               (new_id("reset"), normalized, timestamp))
    if db.execute("SELECT 1 FROM users WHERE role='administrator' AND status='active' LIMIT 1").fetchone():
        db.execute(
            """INSERT INTO notifications(id,title,message,channel,status,recipient,created_at)
               VALUES(?,?,?,'website','unread','Administrators',?)""",
            (new_id("notice"), "Password reset requested",
             f"A user requested a password reset for {normalized}. Review the request in System Management.", timestamp),
        )


def password_reset_requests(db: sqlite3.Connection) -> list[dict]:
    return [dict(row) for row in db.execute(
        """SELECT * FROM password_reset_requests
           ORDER BY CASE status WHEN 'pending' THEN 0 ELSE 1 END,created_at DESC LIMIT 100"""
    )]


def row_data(db: sqlite3.Connection, resource: str, search: str = "", include_inactive: bool = False) -> list[dict] | None:
    pattern = f"%{search}%"
    queries = {
        "bookings": (
            """SELECT b.*,f.name AS facility_name,COALESCE(v.plate,'—') AS plate,
                      COALESCE((SELECT t.status FROM transactions t WHERE t.booking_id=b.id ORDER BY t.created_at DESC LIMIT 1),'pending') AS payment_status
               FROM bookings b JOIN facilities f ON f.id=b.facility_id LEFT JOIN vehicles v ON v.id=b.vehicle_id
               WHERE (?='' OR b.customer_name LIKE ? OR f.name LIKE ? OR b.id LIKE ?) ORDER BY b.created_at DESC""",
            (search, pattern, pattern, pattern),
        ),
        "operations": (
            """SELECT s.*,f.name AS facility_name,v.plate FROM parking_sessions s
               JOIN facilities f ON f.id=s.facility_id JOIN vehicles v ON v.id=s.vehicle_id
               WHERE (?='' OR v.plate LIKE ? OR f.name LIKE ?) ORDER BY s.entered_at DESC""",
            (search, pattern, pattern),
        ),
        "transactions": (
            """SELECT t.*,f.name AS facility_name FROM transactions t JOIN facilities f ON f.id=t.facility_id
               WHERE (?='' OR t.customer_name LIKE ? OR f.name LIKE ? OR t.id LIKE ?) ORDER BY t.created_at DESC""",
            (search, pattern, pattern, pattern),
        ),
        "support": (
            """SELECT s.*,f.name AS facility_name FROM support_requests s LEFT JOIN facilities f ON f.id=s.facility_id
               WHERE (?='' OR s.customer_name LIKE ? OR s.subject LIKE ? OR s.category LIKE ?) ORDER BY s.created_at DESC""",
            (search, pattern, pattern, pattern),
        ),
        "notifications": ("SELECT * FROM notifications ORDER BY created_at DESC", ()),
        "users": ("SELECT id,name,email,role,status,facility_id,created_at FROM users ORDER BY created_at DESC", ()),
        "audit": ("SELECT * FROM audit_logs ORDER BY created_at DESC", ()),
        "inventory": (
            "SELECT i.*,f.name AS facility_name,f.area FROM facility_inventory i JOIN facilities f ON f.id=i.facility_id ORDER BY f.name,i.vehicle_type", ()
        ),
    }
    if resource == "parking-data":
        return list_facilities(db, search, include_inactive=include_inactive)
    if resource in ("password-reset-requests", "auth-password-reset-requests"):
        return password_reset_requests(db)
    if resource not in queries:
        return None
    query, values = queries[resource]
    return [dict(row) for row in db.execute(query, values)]


def stats_for_period(db: sqlite3.Connection, period: str) -> dict:
    days = {"day": 1, "week": 7, "month": 30}.get(period, 7)
    stats = get_stats(db)
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    daily = [dict(row) for row in db.execute(
        """SELECT substr(created_at,1,10) AS date,COUNT(*) AS bookings,
                  SUM(CASE WHEN status='cancelled' THEN 1 ELSE 0 END) AS cancellations
           FROM bookings WHERE created_at>=? GROUP BY substr(created_at,1,10) ORDER BY date""", (since,)
    )]
    by_type = [dict(row) for row in db.execute(
        """SELECT vehicle_type AS vehicleType,SUM(occupied_spaces) AS occupied,SUM(capacity) AS capacity
           FROM facility_inventory WHERE capacity>0 GROUP BY vehicle_type"""
    )]
    popular = [dict(row) for row in db.execute(
        """SELECT f.id,f.name,COUNT(b.id) AS bookings FROM facilities f LEFT JOIN bookings b ON b.facility_id=f.id
           WHERE f.active=1 GROUP BY f.id ORDER BY bookings DESC LIMIT 6"""
    )]
    stats.update(period=period, daily=daily, byType=by_type, mostPopular=popular)
    return stats


def filter_user_rows(user: dict, resource: str, result: list[dict]) -> list[dict]:
    if user["role"] == "parking operator":
        facility_id = user.get("facility_id")
        if resource == "notifications":
            return [row for row in result if (
                (not row.get("facility_id") and row["recipient"] in ("All operators", "Operators"))
                or row.get("facility_id") == facility_id
            )]
        return [row for row in result if row.get("id") == facility_id or row.get("facility_id") == facility_id
                or row.get("facilityId") == facility_id]
    if user["role"] == "customer":
        email = user["email"].lower()
        if resource in ("bookings", "support"):
            return [row for row in result if row.get("customer_email", "").lower() == email]
        if resource == "notifications":
            return [row for row in result if row["recipient"] in ("All customers", user["email"])]
    return result


def issue_rate_limit(bucket: dict[str, list[float]], address: str, limit: int, window: int) -> None:
    timestamp = time.monotonic()
    with RATE_LIMIT_LOCK:
        recent = [attempt for attempt in bucket.get(address, []) if timestamp - attempt < window]
        if len(recent) >= limit:
            raise ApiError(429, "Too many attempts. Please wait before trying again.")
        recent.append(timestamp)
        bucket[address] = recent


def csv_response(rows: list[dict], columns: list[str]) -> bytes:
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(columns)
    for row in rows:
        writer.writerow(row.get(column) for column in columns)
    return output.getvalue().encode("utf-8-sig")


initialize_database()


class SmartParkHandler(BaseHTTPRequestHandler):
    server_version = "SmartPark/1.0"

    def log_message(self, format_string: str, *args: object) -> None:
        sys.stderr.write("%s - %s\n" % (self.address_string(), format_string % args))

    def do_GET(self) -> None:
        self.dispatch()

    def do_POST(self) -> None:
        self.dispatch()

    def do_PATCH(self) -> None:
        self.dispatch()

    def do_PUT(self) -> None:
        self.dispatch()

    def do_HEAD(self) -> None:
        self.dispatch(head_only=True)

    def send_json(self, status: int, payload: object) -> None:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("X-Frame-Options", "DENY")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def send_file_bytes(self, status: int, content_type: str, body: bytes, filename: str | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("X-Frame-Options", "DENY")
        if filename:
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def read_json(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ApiError(400, "Invalid request length.") from None
        if length > 64 * 1024:
            raise ApiError(413, "Request body exceeds 64 KB.")
        if length == 0:
            return {}
        try:
            payload = json.loads(self.rfile.read(length))
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise ApiError(400, "Request body must be valid JSON.") from None
        if not isinstance(payload, dict):
            raise ApiError(400, "Request body must be a JSON object.")
        return payload

    def request_token(self) -> str | None:
        cookie = SimpleCookie()
        try:
            cookie.load(self.headers.get("Cookie", ""))
        except CookieError:
            return None
        morsel = cookie.get("smartpark_session")
        return morsel.value if morsel else None

    def set_session_cookie(self, token: str | None) -> None:
        if token:
            self.send_header("Set-Cookie", f"smartpark_session={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=28800")
        else:
            self.send_header("Set-Cookie", "smartpark_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0")

    def send_auth_json(self, status: int, payload: object, token: str | None) -> None:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.set_session_cookie(token)
        self.end_headers()
        self.wfile.write(body)

    def dispatch(self, head_only: bool = False) -> None:
        try:
            parts = urlsplit(self.path)
            if parts.path.startswith("/api/"):
                self.handle_api(parts)
            elif self.command in ("GET", "HEAD"):
                self.serve_static(unquote(parts.path), head_only)
            else:
                self.send_json(405, {"error": "Method not allowed."})
        except ApiError as error:
            self.send_json(error.status, {"error": str(error)})
        except sqlite3.IntegrityError as error:
            sys.stderr.write(f"Database constraint rejected a request: {error}\n")
            self.send_json(409, {"error": "The requested change conflicts with existing parking records."})
        except Exception as error:
            sys.stderr.write(f"Request failed: {type(error).__name__}: {error}\n")
            self.send_json(500, {"error": "An internal server error occurred."})

    def serve_static(self, request_path: str, head_only: bool) -> None:
        name = "parking.html" if request_path in ("", "/") else request_path.lstrip("/\\")
        if name not in STATIC_FILES:
            self.send_file_bytes(404, "text/plain; charset=utf-8", b"Not found")
            return
        target = ROOT / name
        if not target.is_file():
            self.send_file_bytes(404, "text/plain; charset=utf-8", b"Not found")
            return
        mime = {"parking.html": "text/html; charset=utf-8", "style.css": "text/css; charset=utf-8",
                "script.js": "text/javascript; charset=utf-8"}[name]
        data = target.read_bytes()
        if head_only:
            self.send_response(200)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
        else:
            self.send_file_bytes(200, mime, data)

    def handle_api(self, parts) -> None:
        route = [unquote(part) for part in parts.path.split("/") if part]
        if len(route) < 2:
            raise ApiError(404, "API endpoint not found.")
        _, resource, *remaining = route
        resource_id = remaining[0] if remaining else None
        action = remaining[1] if len(remaining) > 1 else None
        if resource == "operations" and resource_id in ("entry", "exit") and action is None:
            action, resource_id = resource_id, None
        query_params = parse_qs(parts.query, keep_blank_values=True)
        query = query_params.get("q", [""])[0].strip()
        body = self.read_json() if self.command in ("POST", "PATCH", "PUT") else {}
        with connect() as db:
            user = get_session(db, self.request_token())
            public = resource == "auth" and resource_id in (
                "setup", "login", "password-reset-request", "password-reset-complete",
            )
            if self.command == "GET" and resource == "auth" and resource_id == "session":
                self.send_json(200, {
                    "authenticated": bool(user),
                    "setupRequired": db.execute("SELECT 1 FROM users LIMIT 1").fetchone() is None,
                    "user": user,
                })
                return
            if not public and not user:
                raise ApiError(401, "Sign in to access the SmartPark workspace.")
            if public:
                self.handle_public_auth(db, resource_id, body)
                return
            if user and resource == "auth" and resource_id == "logout" and self.command == "POST":
                token = self.request_token()
                if token:
                    db.execute("DELETE FROM auth_sessions WHERE token_hash=?", (hashlib.sha256(token.encode()).hexdigest(),))
                self.send_auth_json(200, {"success": True}, None)
                return
            if user and resource == "auth" and resource_id == "change-password" and self.command == "POST":
                change_password(db, user["id"], body.get("currentPassword"), body.get("password"))
                self.send_auth_json(200, {"success": True}, None)
                return
            if self.command == "GET":
                self.handle_get(db, user, resource, resource_id, action, query_params, query)
            else:
                self.handle_write(db, user, resource, resource_id, action, body)

    def handle_public_auth(self, db: sqlite3.Connection, action: str, body: dict) -> None:
        address = self.client_address[0] if self.client_address else "local"
        if action == "setup" and self.command == "POST":
            user = setup_administrator(db, body)
            token, expiry = create_session(db, user["id"])
            self.send_auth_json(201, {"user": user, "expiresAt": expiry}, token)
            return
        if action == "login" and self.command == "POST":
            issue_rate_limit(LOGIN_ATTEMPTS, address, 10, 900)
            user = authenticate(db, body.get("email"), body.get("password"))
            if not user:
                raise ApiError(401, "Email or password is incorrect, or the account has been deactivated.")
            LOGIN_ATTEMPTS.pop(address, None)
            token, expiry = create_session(db, user["id"])
            self.send_auth_json(200, {"user": user, "expiresAt": expiry}, token)
            return
        if action == "password-reset-request" and self.command == "POST":
            issue_rate_limit(RESET_ATTEMPTS, address, 3, 600)
            request_password_reset(db, body.get("email"))
            self.send_json(200, {
                "success": True,
                "message": "If this account exists, its administrator has been notified. Password reset codes expire after 30 minutes.",
            })
            return
        if action == "password-reset-complete" and self.command == "POST":
            complete_password_reset(db, body.get("email"), body.get("resetCode"), body.get("password"))
            self.send_json(200, {"success": True})
            return
        raise ApiError(405, "Method not allowed.")

    def authorize(self, db: sqlite3.Connection, user: dict, method: str,
                  resource: str, resource_id: str | None, action: str | None, body: dict) -> None:
        role = user["role"]
        if role == "administrator":
            return
        facility_id = user.get("facility_id")

        def facility_for_booking(booking_id: str):
            return db.execute("SELECT facility_id FROM bookings WHERE id=?", (booking_id,)).fetchone()

        if method == "GET":
            allowed = (
                {"home", "stats", "facilities", "operations", "bookings", "parking-data", "notifications", "support"}
                if role == "parking operator"
                else {"home", "stats", "facilities", "bookings", "notifications", "support"}
            )
            if resource not in allowed:
                raise ApiError(403, "Your account role cannot access this module.")
            if role == "parking operator" and resource in ("facilities", "bookings", "operations", "parking-data") and resource_id:
                row = facility_for_booking(resource_id) if resource == "bookings" else None
                target = row["facility_id"] if row else resource_id
                if resource == "operations":
                    row = db.execute("SELECT facility_id FROM parking_sessions WHERE id=?", (resource_id,)).fetchone()
                    target = row["facility_id"] if row else resource_id
                if target != facility_id:
                    raise ApiError(403, "You do not have access to this parking facility.")
            if role == "customer" and resource == "facilities" and resource_id:
                row = db.execute("SELECT active FROM facilities WHERE id=?", (resource_id,)).fetchone()
                if not row or not row["active"]:
                    raise ApiError(404, "Facility not found.")
            if role == "customer" and resource == "bookings" and resource_id:
                row = db.execute("SELECT customer_email FROM bookings WHERE id=?", (resource_id,)).fetchone()
                if not row or row["customer_email"].lower() != user["email"].lower():
                    raise ApiError(403, "You can only view your own reservation.")
            return

        if role == "customer":
            if method == "POST" and ((resource == "bookings" and not resource_id) or resource == "support"):
                return
            if method == "POST" and resource == "bookings" and resource_id and action == "cancel":
                row = db.execute("SELECT customer_email FROM bookings WHERE id=?", (resource_id,)).fetchone()
                if not row or row["customer_email"].lower() != user["email"].lower():
                    raise ApiError(403, "You can only cancel your own reservation.")
                return
            if method == "PATCH" and resource == "notifications" and action == "read":
                row = db.execute("SELECT recipient FROM notifications WHERE id=?", (resource_id,)).fetchone()
                if row and row["recipient"] in ("All customers", user["email"]):
                    return
            if method == "PATCH" and resource == "support" and action == "rating":
                row = db.execute("SELECT customer_email,status FROM support_requests WHERE id=?", (resource_id,)).fetchone()
                if row and row["status"] == "resolved" and row["customer_email"].lower() == user["email"].lower():
                    return
            raise ApiError(403, "Customer accounts can create their own reservations and support requests.")

        if role == "parking operator":
            if method == "POST" and resource == "operations":
                if action == "entry":
                    target = body.get("facilityId")
                elif action == "exit":
                    row = db.execute("SELECT facility_id FROM parking_sessions WHERE id=?", (body.get("sessionId"),)).fetchone()
                    if not row:
                        raise ApiError(404, "Active parking session not found.")
                    target = row["facility_id"]
                else:
                    raise ApiError(403, "Your account role cannot perform this operation.")
                if target != facility_id:
                    raise ApiError(403, "You do not have access to this parking facility.")
                return
            if method == "POST" and resource == "bookings" and action in ("check-in", "cancel"):
                row = facility_for_booking(resource_id or "")
                if not row or row["facility_id"] != facility_id:
                    raise ApiError(403, "You do not have access to this parking facility.")
                return
            if method == "PATCH" and resource == "facilities" and action == "availability" and resource_id == facility_id:
                return
            if method == "PATCH" and resource == "notifications" and action == "read":
                row = db.execute("SELECT facility_id,recipient FROM notifications WHERE id=?", (resource_id,)).fetchone()
                if row and (row["facility_id"] in (None, facility_id) and row["recipient"] in ("All operators", "Operators")):
                    return
            if method == "PATCH" and resource == "support" and resource_id:
                row = db.execute("SELECT facility_id FROM support_requests WHERE id=?", (resource_id,)).fetchone()
                if row and row["facility_id"] in (None, facility_id):
                    return
            if method == "POST" and resource == "support" and body.get("facilityId") in (None, facility_id):
                return
        raise ApiError(403, "Your account role cannot perform this operation.")

    def handle_get(self, db: sqlite3.Connection, user: dict, resource: str,
                   resource_id: str | None, action: str | None, params: dict, query: str) -> None:
        self.authorize(db, user, "GET", resource, resource_id, action, {})
        if resource == "facilities" and resource_id:
            facility = get_facility(db, resource_id)
            if facility and user["role"] == "customer" and not facility["active"]:
                facility = None
            if not facility:
                raise ApiError(404, "Facility not found.")
            self.send_json(200, facility)
            return
        if resource == "facilities":
            facilities = list_facilities(
                db, query, params.get("zone", [""])[0], params.get("vehicleType", [""])[0],
                params.get("includeInactive", ["false"])[0] == "true",
            )
            if user["role"] == "parking operator":
                facilities = [item for item in facilities if item["id"] == user.get("facility_id")]
            if user["role"] == "customer":
                facilities = [item for item in facilities if item["active"]]
            self.send_json(200, facilities)
            return
        if resource == "home":
            data = get_stats(db)
            if user["role"] == "parking operator":
                facility_id = user.get("facility_id")
                data["recentFacilities"] = [row for row in data["recentFacilities"] if row["id"] == facility_id]
                data["alerts"] = [row for row in data["alerts"] if row["facilityId"] == facility_id]
                data["recentBookings"] = [row for row in data["recentBookings"] if row["facility_id"] == facility_id]
                data["recentActivity"] = []
            elif user["role"] == "customer":
                data["recentBookings"] = [row for row in data["recentBookings"]
                                          if row["customer_email"].lower() == user["email"].lower()]
                data["recentActivity"] = []
            self.send_json(200, data)
            return
        if resource == "stats":
            stats = stats_for_period(db, params.get("period", ["week"])[0])
            if user["role"] == "parking operator":
                facility_id = user.get("facility_id")
                stats["recentFacilities"] = [row for row in stats["recentFacilities"] if row["id"] == facility_id]
                stats["alerts"] = [row for row in stats["alerts"] if row["facilityId"] == facility_id]
                stats["recentBookings"] = [row for row in stats["recentBookings"] if row["facility_id"] == facility_id]
                stats["mostPopular"] = [row for row in stats["mostPopular"] if row["id"] == facility_id]
                stats["recentActivity"] = []
            elif user["role"] == "customer":
                stats["recentBookings"] = [row for row in stats["recentBookings"]
                                           if row["customer_email"].lower() == user["email"].lower()]
                stats["recentActivity"] = []
            self.send_json(200, stats)
            return
        if resource == "bookings" and resource_id and action == "check-in":
            row = db.execute(
                "SELECT b.*,f.name AS facility_name FROM bookings b JOIN facilities f ON f.id=b.facility_id WHERE b.id=?",
                (resource_id,),
            ).fetchone()
            if not row:
                raise ApiError(404, "Booking not found.")
            self.send_json(200, dict(row))
            return
        if resource == "settings":
            self.send_json(200, [dict(row) for row in db.execute(
                "SELECT key,value,updated_at AS updatedAt FROM app_settings ORDER BY key")])
            return
        if resource == "auth" and resource_id == "password-reset-requests":
            if user["role"] != "administrator":
                raise ApiError(403, "Administrator access is required for this action.")
            self.send_json(200, password_reset_requests(db))
            return
        result = row_data(db, resource, query, params.get("includeInactive", ["false"])[0] == "true")
        if result is None:
            raise ApiError(404, "API resource not found.")
        result = filter_user_rows(user, resource, result)
        self.send_json(200, result)

    def handle_write(self, db: sqlite3.Connection, user: dict, resource: str,
                     resource_id: str | None, action: str | None, body: dict) -> None:
        method = self.command
        self.authorize(db, user, method, resource, resource_id, action, body)
        if method == "POST" and resource == "facilities":
            self.send_json(201, create_facility(db, validate_facility(body)))
            return
        if method == "PATCH" and resource == "facilities" and resource_id and action == "availability":
            facility = get_facility(db, resource_id)
            occupancy = body.get("occupancy")
            if not facility:
                raise ApiError(404, "Facility not found.")
            if not isinstance(occupancy, dict):
                raise ApiError(400, "Enter updated occupied spaces for each vehicle type.")
            with write_transaction(db):
                for vehicle_type, amount in occupancy.items():
                    require_enum(vehicle_type, "Vehicle type", VEHICLE_TYPES)
                    inventory = next((item for item in facility["vehicles"] if item["vehicleType"] == vehicle_type), None)
                    if (not inventory or isinstance(amount, bool) or not isinstance(amount, int) or amount < 0
                            or amount > inventory["capacity"] - inventory["reservedSpaces"]):
                        raise ApiError(400, f"Occupied spaces for {vehicle_type} must be between zero and its capacity after reservations.")
                    db.execute(
                        "UPDATE facility_inventory SET occupied_spaces=? WHERE facility_id=? AND vehicle_type=?",
                        (amount, resource_id, vehicle_type),
                    )
                source = require_text(body.get("source", "Operator report"), "Availability source")
                db.execute("UPDATE facilities SET availability_updated_at=?,availability_source=? WHERE id=?",
                           (now(), source, resource_id))
                log_action(db, "updated availability", "facility", resource_id, {"occupancy": occupancy, "source": source})
            self.send_json(200, get_facility(db, resource_id))
            return
        if method in ("PATCH", "PUT") and resource == "facilities" and resource_id:
            before = get_facility(db, resource_id)
            result = update_facility(db, resource_id, validate_facility(body, partial=True))
            if not result:
                raise ApiError(404, "Facility not found.")
            if not before["temporarilyClosed"] and result["temporarilyClosed"]:
                self.add_notification(
                    db, "Temporary facility closure",
                    f"{result['name']} is temporarily closed. {result['closure_reason'] or 'Please select another parking location.'}",
                    "All customers", result["id"],
                )
            self.send_json(200, result)
            return
        if method == "POST" and resource == "bookings" and not resource_id:
            if user["role"] == "customer":
                body.update(customerName=user["name"], customerEmail=user["email"])
            booking = save_booking(db, body)
            self.create_availability_alert(db, booking["facility_id"])
            self.send_json(201, booking)
            return
        if method == "POST" and resource == "operations" and action == "entry":
            session = vehicle_entry(db, body, body.get("bookingId"))
            self.create_availability_alert(db, body["facilityId"])
            self.send_json(201, session)
            return
        if method == "POST" and resource == "operations" and action == "exit":
            self.send_json(200, vehicle_exit(db, body))
            return
        if method == "POST" and resource == "bookings" and resource_id and action == "check-in":
            booking = db.execute("SELECT * FROM bookings WHERE id=?", (resource_id,)).fetchone()
            if not booking or booking["status"] != "confirmed":
                raise ApiError(409, "A confirmed booking is required for check-in.")
            session = vehicle_entry(db, {**body, "facilityId": booking["facility_id"], "vehicleType": booking["vehicle_type"]}, booking["id"])
            self.send_json(200, session)
            return
        if method == "POST" and resource == "bookings" and resource_id and action == "cancel":
            self.cancel_booking(db, user, resource_id, body)
            return
        if method == "POST" and resource == "transactions":
            self.update_payment(db, body)
            return
        if method == "POST" and resource == "support":
            self.create_support(db, user, body)
            return
        if method == "POST" and resource == "notifications":
            self.create_message(db, body)
            return
        if method == "PATCH" and resource == "notifications" and resource_id and action == "read":
            row = db.execute("SELECT recipient,facility_id FROM notifications WHERE id=?", (resource_id,)).fetchone()
            if not row:
                raise ApiError(404, "Notification not found.")
            if user["role"] == "customer" and row["recipient"] not in ("All customers", user["email"]):
                raise ApiError(403, "You cannot change another user's notification.")
            if user["role"] == "parking operator" and (
                row["facility_id"] not in (None, user.get("facility_id"))
                or row["recipient"] not in ("All operators", "Operators")
            ):
                raise ApiError(403, "You cannot change another user's notification.")
            db.execute("UPDATE notifications SET status='read' WHERE id=?", (resource_id,))
            self.send_json(200, {"success": True})
            return
        if method == "PATCH" and resource == "support" and resource_id and action == "rating":
            self.rate_support(db, user, resource_id, body)
            return
        if method == "PATCH" and resource == "support" and resource_id:
            self.update_support(db, resource_id, body)
            return
        if method == "POST" and resource == "users" and resource_id and action == "password-reset":
            reset = issue_password_reset(db, resource_id)
            self.send_json(200, reset)
            return
        if method == "POST" and resource == "users" and not resource_id:
            self.create_user(db, body)
            return
        if method == "PATCH" and resource == "users" and resource_id:
            self.update_user(db, user, resource_id, body)
            return
        if method == "PATCH" and resource == "settings" and resource_id:
            if resource_id in ("availabilityAlertThreshold", "availabilityStaleMinutes"):
                if not re.fullmatch(r"\d+", str(body.get("value", ""))) or int(body["value"]) <= 0:
                    raise ApiError(400, "Alert thresholds and availability age must be a positive whole number.")
            if not isinstance(body.get("value"), (str, int, float, bool)):
                raise ApiError(400, "A setting value is required.")
            timestamp = now()
            db.execute(
                """INSERT INTO app_settings(key,value,updated_at) VALUES(?,?,?)
                   ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at""",
                (resource_id, str(body["value"]), timestamp),
            )
            log_action(db, "updated setting", "setting", resource_id, {"value": body["value"]})
            self.send_json(200, dict(db.execute(
                "SELECT key,value,updated_at AS updatedAt FROM app_settings WHERE key=?", (resource_id,)
            ).fetchone()))
            return
        if method == "POST" and resource == "export":
            self.export_csv(db, body)
            return
        if method == "POST" and resource == "backup":
            if user["role"] != "administrator":
                raise ApiError(403, "Administrator access is required for this action.")
            enabled = db.execute("SELECT value FROM app_settings WHERE key='backupEnabled'").fetchone()
            if enabled and enabled["value"].lower() == "false":
                raise ApiError(403, "Database backups are disabled in System Management.")
            self.download_backup(db)
            return
        raise ApiError(404, "API endpoint not found.")

    def add_notification(self, db: sqlite3.Connection, title: str, message: str,
                          recipient: str, facility_id: str | None = None, booking_id: str | None = None) -> None:
        db.execute(
            """INSERT INTO notifications(id,title,message,channel,status,recipient,facility_id,booking_id,created_at)
               VALUES(?,?,?,'website','unread',?,?,?,?)""",
            (new_id("notice"), title, message, recipient, facility_id, booking_id, now()),
        )

    def create_availability_alert(self, db: sqlite3.Connection, facility_id: str) -> None:
        facility = get_facility(db, facility_id)
        if not facility or not facility["active"] or facility["temporarilyClosed"] or not facility["capacity"]:
            return
        row = db.execute("SELECT value FROM app_settings WHERE key='availabilityAlertThreshold'").fetchone()
        threshold = float(row["value"] if row else "10") / 100
        if facility["availableSpaces"] / facility["capacity"] > threshold:
            return
        since = (datetime.now(timezone.utc) - timedelta(minutes=60)).isoformat()
        if db.execute(
            """SELECT 1 FROM notifications WHERE facility_id=? AND title='Low parking availability'
               AND created_at>? LIMIT 1""", (facility_id, since)
        ).fetchone():
            return
        self.add_notification(db, "Low parking availability",
                              f"{facility['name']} has {facility['availableSpaces']} remaining parking spaces.",
                              "All operators", facility_id)

    def cancel_booking(self, db: sqlite3.Connection, user: dict, booking_id: str, body: dict) -> None:
        booking = db.execute("SELECT * FROM bookings WHERE id=?", (booking_id,)).fetchone()
        if not booking:
            raise ApiError(404, "Booking not found.")
        if booking["status"] not in ("pending", "confirmed"):
            raise ApiError(409, "Only pending or confirmed bookings can be cancelled.")
        facility = db.execute("SELECT cancellation_hours FROM facilities WHERE id=?", (booking["facility_id"],)).fetchone()
        if user["role"] == "customer":
            start = datetime.fromisoformat(booking["starts_at"].replace("Z", "+00:00"))
            cutoff = start - timedelta(hours=facility["cancellation_hours"])
            if datetime.now(timezone.utc) > cutoff:
                raise ApiError(409, "The free-cancellation cutoff for this booking has passed. Contact the parking operator for help.")
        timestamp = now()
        reason = str(body.get("reason") or "Cancelled by customer")
        with write_transaction(db):
            changed = db.execute(
                """UPDATE bookings SET status='cancelled',cancelled_at=?,cancellation_reason=?
                   WHERE id=? AND status IN ('pending','confirmed')""",
                (timestamp, reason, booking_id),
            ).rowcount
            if not changed:
                raise ApiError(409, "Only pending or confirmed bookings can be cancelled.")
            refund = db.execute("UPDATE transactions SET status='refunded',settled_at=? WHERE booking_id=? AND status='completed'",
                                (timestamp, booking_id)).rowcount
            db.execute("UPDATE transactions SET status='failed',settled_at=? WHERE booking_id=? AND status='pending'",
                       (timestamp, booking_id))
            db.execute("UPDATE facilities SET availability_updated_at=? WHERE id=?", (timestamp, booking["facility_id"]))
            self.add_notification(
                db, "Booking cancelled",
                f"Your reservation {booking_id} has been cancelled." + (" Your completed payment has been marked for refund." if refund else ""),
                booking["customer_email"] or booking["customer_name"], booking["facility_id"], booking_id,
            )
            log_action(db, "cancelled", "booking", booking_id, {"reason": reason})
        self.send_json(200, dict(db.execute("SELECT * FROM bookings WHERE id=?", (booking_id,)).fetchone()))

    def update_payment(self, db: sqlite3.Connection, body: dict) -> None:
        transaction = db.execute("SELECT * FROM transactions WHERE id=?", (body.get("id"),)).fetchone()
        if not transaction:
            raise ApiError(404, "Transaction not found.")
        status = require_enum(body.get("status"), "Payment status", ("completed", "pending", "failed", "refunded"))
        timestamp = now() if status in ("completed", "refunded") else None
        db.execute("UPDATE transactions SET status=?,payment_method=COALESCE(?,payment_method),settled_at=? WHERE id=?",
                   (status, body.get("paymentMethod"), timestamp, transaction["id"]))
        log_action(db, "updated payment", "transaction", transaction["id"], {"status": status})
        self.send_json(200, dict(db.execute("SELECT * FROM transactions WHERE id=?", (transaction["id"],)).fetchone()))

    def create_support(self, db: sqlite3.Connection, user: dict, body: dict) -> None:
        customer_name = user["name"] if user["role"] == "customer" else require_text(body.get("customerName"), "Customer name")
        customer_email = user["email"] if user["role"] == "customer" else str(body.get("customerEmail") or "")
        facility_id = body.get("facilityId") or None
        if facility_id and not db.execute("SELECT 1 FROM facilities WHERE id=?", (facility_id,)).fetchone():
            raise ApiError(400, "The selected parking facility does not exist.")
        case_id, timestamp = new_id("case"), now()
        subject = require_text(body.get("subject"), "Subject")
        with write_transaction(db):
            db.execute(
                """INSERT INTO support_requests(id,customer_name,customer_email,category,subject,message,facility_id,created_at,updated_at)
                   VALUES(?,?,?,?,?,?,?,?,?)""",
                (case_id, customer_name, customer_email, require_text(body.get("category"), "Category"),
                 subject, require_text(body.get("message"), "Message", 4000), facility_id, timestamp, timestamp),
            )
            log_action(db, "created", "support request", case_id, {"subject": subject})
            self.add_notification(db, "New customer support request", subject, "Operators", facility_id)
        self.send_json(201, dict(db.execute("SELECT * FROM support_requests WHERE id=?", (case_id,)).fetchone()))

    def create_message(self, db: sqlite3.Connection, body: dict) -> None:
        title = require_text(body.get("title"), "Notification title")
        message = require_text(body.get("message"), "Message", 4000)
        recipient = body.get("recipient") or "All operators"
        facility_id = body.get("facilityId") or None
        facility_audience = db.execute(
            "SELECT id FROM facilities WHERE name=? COLLATE NOCASE AND active=1", (recipient,)
        ).fetchone()
        if (recipient not in ("All operators", "All customers", "Operators")
                and not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", str(recipient))
                and not facility_audience):
            raise ApiError(400, "Choose a valid notification audience, facility, or customer email.")
        if facility_audience and not facility_id:
            facility_id = facility_audience["id"]
        if facility_id and not db.execute("SELECT 1 FROM facilities WHERE id=?", (facility_id,)).fetchone():
            raise ApiError(400, "The selected parking facility does not exist.")
        notice_id, timestamp = new_id("notice"), now()
        db.execute(
            """INSERT INTO notifications(id,title,message,channel,status,recipient,facility_id,created_at)
               VALUES(?,?,?,'website','unread',?,?,?)""",
            (notice_id, title, message, recipient, facility_id, timestamp),
        )
        log_action(db, "sent", "notification", notice_id, {"title": title})
        self.send_json(201, dict(db.execute("SELECT * FROM notifications WHERE id=?", (notice_id,)).fetchone()))

    def rate_support(self, db: sqlite3.Connection, user: dict, case_id: str, body: dict) -> None:
        ticket = db.execute("SELECT * FROM support_requests WHERE id=?", (case_id,)).fetchone()
        rating = body.get("rating")
        if not ticket:
            raise ApiError(404, "Support request not found.")
        if (ticket["status"] != "resolved" or isinstance(rating, bool) or not isinstance(rating, int)
                or rating < 1 or rating > 5):
            raise ApiError(400, "Submit a 1–5 star rating after the case is resolved.")
        db.execute("UPDATE support_requests SET rating=?,updated_at=? WHERE id=?", (rating, now(), case_id))
        log_action(db, "rated", "support request", case_id, {"rating": rating})
        self.send_json(200, dict(db.execute("SELECT * FROM support_requests WHERE id=?", (case_id,)).fetchone()))

    def update_support(self, db: sqlite3.Connection, case_id: str, body: dict) -> None:
        status = require_enum(body.get("status"), "Support status", ("open", "in_progress", "resolved", "rejected"))
        rating = body.get("rating")
        if rating is not None and (isinstance(rating, bool) or not isinstance(rating, int) or not 1 <= rating <= 5):
            raise ApiError(400, "Customer feedback ratings must be from 1 to 5.")
        result = db.execute(
            """UPDATE support_requests SET status=?,assigned_to=COALESCE(?,assigned_to),
               rating=COALESCE(?,rating),updated_at=? WHERE id=?""",
            (status, body.get("assignedTo") or None, rating, now(), case_id),
        )
        if not result.rowcount:
            raise ApiError(404, "Support request not found.")
        self.send_json(200, dict(db.execute("SELECT * FROM support_requests WHERE id=?", (case_id,)).fetchone()))

    def create_user(self, db: sqlite3.Connection, body: dict) -> None:
        role = require_enum(body.get("role"), "Role", ("administrator", "parking operator", "customer"))
        name, email = require_text(body.get("name"), "Name"), require_text(body.get("email"), "Email", 254).lower()
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
            raise ApiError(400, "Enter a valid email address.")
        facility_id = body.get("facilityId") or None
        if role == "parking operator" and not facility_id:
            raise ApiError(400, "Assign parking operators to a facility before creating their account.")
        if facility_id and not db.execute("SELECT 1 FROM facilities WHERE id=?", (facility_id,)).fetchone():
            raise ApiError(400, "The selected parking facility does not exist.")
        user_id, timestamp = new_id("user"), now()
        try:
            with write_transaction(db):
                db.execute("INSERT INTO users(id,name,email,role,status,facility_id,created_at) VALUES(?,?,?,?,'active',?,?)",
                           (user_id, name, email, role, facility_id, timestamp))
                log_action(db, "created", "user", user_id, {"name": name, "email": email, "role": role})
        except sqlite3.IntegrityError:
            raise ApiError(409, "This email address is already registered.") from None
        result = dict(db.execute("SELECT id,name,email,role,status,facility_id,created_at FROM users WHERE id=?", (user_id,)).fetchone())
        self.send_json(201, result)

    def update_user(self, db: sqlite3.Connection, actor: dict, user_id: str, body: dict) -> None:
        if user_id == actor["id"]:
            raise ApiError(409, "Manage administrator access from a different active administrator account.")
        status = require_enum(body.get("status"), "Account status", ("active", "inactive"))
        role = require_enum(body["role"], "Role", ("administrator", "parking operator", "customer")) if body.get("role") else None
        current = db.execute("SELECT role,status,facility_id FROM users WHERE id=?", (user_id,)).fetchone()
        if not current:
            raise ApiError(404, "User not found.")
        facility_id = body.get("facilityId") or None
        if (role or current["role"]) == "parking operator" and not facility_id:
            raise ApiError(400, "Assign parking operators to a facility.")
        if facility_id and not db.execute("SELECT 1 FROM facilities WHERE id=?", (facility_id,)).fetchone():
            raise ApiError(400, "The selected parking facility does not exist.")
        if current["role"] == "administrator" and (status == "inactive" or (role and role != "administrator")):
            count = db.execute("SELECT COUNT(*) FROM users WHERE role='administrator' AND status='active'").fetchone()[0]
            if count <= 1:
                raise ApiError(409, "Keep at least one active administrator on the system.")
        db.execute("UPDATE users SET status=?,role=COALESCE(?,role),facility_id=? WHERE id=?",
                   (status, role, facility_id, user_id))
        log_action(db, "updated", "user", user_id, body)
        self.send_json(200, dict(db.execute(
            "SELECT id,name,email,role,status,facility_id,created_at FROM users WHERE id=?", (user_id,)
        ).fetchone()))

    def export_csv(self, db: sqlite3.Connection, body: dict) -> None:
        if body.get("type") == "transactions":
            rows = [dict(row) for row in db.execute(
                """SELECT t.id,f.name AS facility,t.customer_name,t.amount,t.payment_method,t.status,t.description,t.created_at,t.settled_at
                   FROM transactions t JOIN facilities f ON f.id=t.facility_id ORDER BY t.created_at DESC"""
            )]
            columns = ["id", "facility", "customer_name", "amount", "payment_method", "status", "description", "created_at", "settled_at"]
            filename = "smartpark-transactions.csv"
        else:
            rows = [
                {"facility": facility["name"], "address": facility["address"], "zone": facility["zone"],
                 "vehicleType": vehicle["vehicleType"], "capacity": vehicle["capacity"],
                 "occupied": vehicle["occupiedSpaces"], "reserved": vehicle["reservedSpaces"],
                 "available": vehicle["availableSpaces"], "hourlyRate": vehicle["hourlyRate"],
                 "dailyRate": vehicle["dailyRate"], "updatedAt": facility["availabilityUpdatedAt"]}
                for facility in list_facilities(db, include_inactive=True) for vehicle in facility["vehicles"]
            ]
            columns = ["facility", "address", "zone", "vehicleType", "capacity", "occupied", "reserved",
                       "available", "hourlyRate", "dailyRate", "updatedAt"]
            filename = "smartpark-data.csv"
        self.send_file_bytes(200, "text/csv; charset=utf-8", csv_response(rows, columns), filename)

    def download_backup(self, db: sqlite3.Connection) -> None:
        db.execute("PRAGMA wal_checkpoint(FULL)")
        filename = f"smartpark-backup-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.sqlite"
        backup = sqlite3.connect(":memory:")
        db.backup(backup)
        data = backup.serialize()
        backup.close()
        self.send_file_bytes(200, "application/vnd.sqlite3", data, filename)


def main() -> None:
    try:
        server = ThreadingHTTPServer((HOST, PORT), SmartParkHandler)
    except OSError as error:
        raise SystemExit(f"Could not start SmartPark at {HOST}:{PORT}: {error}") from error
    print(f"SmartPark is available at http://{HOST}:{PORT}")
    print(f"SQLite database: {DATABASE_PATH}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nSmartPark server stopped.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
